window.addEventListener('pywebviewready', () => {
  document.documentElement.classList.add('native');
  document.querySelector('#macFloat').onclick = () => window.pywebview.api.show_floating();
  document.querySelector('#macOpen').onclick = () => window.pywebview.api.show_main();
});
