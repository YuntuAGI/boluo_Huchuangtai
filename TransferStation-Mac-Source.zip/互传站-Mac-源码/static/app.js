const $ = (selector) => document.querySelector(selector);
const state = { files: [], messages: [], socket: null, base: null, ready: false, loading: false, networkBusy: false, requests: new Set() };
const api = (path) => (state.base || '') + path;
const deviceName = $("#deviceName");
const defaultName = /Mac|iPhone|iPad/.test(navigator.platform + navigator.userAgent) ? "我的 Mac" : "Windows 主机";

deviceName.value = localStorage.getItem("landrop-device-name") || defaultName;
deviceName.addEventListener("change", () => {
  deviceName.value = deviceName.value.trim() || defaultName;
  localStorage.setItem("landrop-device-name", deviceName.value);
  renderChat(false);
});

function escapeHtml(value) {
  const element = document.createElement("div");
  element.textContent = value;
  return element.innerHTML.replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let value = bytes / 1024;
  let unit = units[0];
  for (let index = 1; value >= 1024 && index < units.length; index += 1) {
    value /= 1024;
    unit = units[index];
  }
  return `${value >= 10 ? value.toFixed(1) : value.toFixed(2)} ${unit}`;
}

function formatTime(timestamp) {
  return new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit" }).format(new Date(timestamp));
}

function avatarText(sender) {
  return [...(sender || "访客")][0].toUpperCase();
}

function fileExtension(name) {
  const extension = name.includes(".") ? name.split(".").pop() : "文件";
  return extension.slice(0, 5).toUpperCase();
}

let toastTimer;
function toast(text) {
  const element = $("#toast");
  element.textContent = text;
  element.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove("show"), 1900);
}

async function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const input = document.createElement("textarea");
  input.value = text;
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  document.execCommand("copy");
  input.remove();
}

function combinedItems() {
  return [
    ...state.messages.map((item) => ({ ...item, kind: "message" })),
    ...state.files.map((item) => ({ ...item, kind: "file" })),
  ].sort((left, right) => left.created_at - right.created_at);
}

function textBubble(item) {
  return `<div class="bubble text-bubble" data-copy="${escapeHtml(item.content)}" title="点击复制文字">${escapeHtml(item.content)}</div>`;
}

function fileBubble(item) {
  if ((item.type || "").startsWith("image/")) {
    return `<div class="bubble image-bubble">
      <a class="image-link" href="${api('/api/files/' + encodeURIComponent(item.id))}" download="${escapeHtml(item.name)}" title="单击查看大图，双击下载原图">
        <img src="${api('/api/files/' + encodeURIComponent(item.id))}?inline=1" alt="${escapeHtml(item.name)}" loading="lazy" />
        <span class="image-caption">单击放大 · 双击下载</span>
      </a>
    </div>`;
  }
  return `<div class="bubble file-bubble"><a class="file-card" href="${api('/api/files/' + encodeURIComponent(item.id))}" download>
    <span class="file-copy"><span class="file-name" title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</span><span class="file-size">${formatSize(item.size)} · 点击下载</span></span>
    <span class="file-type">${escapeHtml(fileExtension(item.name))}</span>
  </a></div>`;
}

function renderChat(shouldScroll = true) {
  const list = $("#chatList");
  const items = combinedItems();
  $("#itemCount").textContent = `${items.length} 条内容`;
  if (!items.length) {
    $("#sessionPreview").textContent = "文字、文件、剪贴板图片";
    list.innerHTML = '<div class="empty-chat"><div class="empty-mark" aria-hidden="true">互</div><strong>开始互传</strong><span>发送文字、文件，或直接粘贴剪贴板图片</span></div>';
    return;
  }
  list.innerHTML = items.map((item) => {
    const mine = item.sender === deviceName.value;
    return `<article class="message-row${mine ? " mine" : ""}">
      <div class="avatar" aria-hidden="true">${escapeHtml(avatarText(item.sender))}</div>
      <div class="message-body">
        <div class="sender"><span>${escapeHtml(item.sender)}</span><time>${formatTime(item.created_at)}</time></div>
        ${item.kind === "message" ? textBubble(item) : fileBubble(item)}
      </div>
    </article>`;
  }).join("");
  const last = items.at(-1);
  $("#sessionPreview").textContent = last.kind === "message" ? last.content : `[文件] ${last.name}`;
  if (shouldScroll) requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
}

function setConnection(online) {
  state.ready = online;
  $(".connection-card").classList.toggle("online", online);
  $("#statusText").textContent = online ? "局域网在线" : "正在重连";
  $("#onlineLabel").textContent = online ? "在线" : "连接中";
  $("#fileButton").disabled = !online;
  if ($('#sendButton').textContent !== '发送中') $('#sendButton').disabled = !online;
}

async function load() {
  if (state.base === null || state.loading) return;
  const base = state.base;
  state.loading = true;
  try {
    const [feedResponse, statusResponse] = await Promise.all([fetch(api("/api/feed"), {signal: AbortSignal.timeout(4000)}), fetch(api("/api/status"), {signal: AbortSignal.timeout(4000)})]);
    if (!feedResponse.ok || !statusResponse.ok) throw new Error("服务不可用");
    const feed = await feedResponse.json();
    const status = await statusResponse.json();
    if (base !== state.base) return;
    state.files = feed.files;
    state.messages = feed.messages;
    renderChat();
    connect();
  } catch (error) {
    $("#statusText").textContent = "连接失败";
  } finally {
    state.loading = false;
  }
}

function connect() {
  if (state.socket && state.socket.readyState < 2) return;
  if (state.base === null) return;
  const url = new URL(api('/api/live'), location.href);
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  const socket = new WebSocket(url);
  state.socket = socket;
  socket.addEventListener("open", async () => {
    if (socket !== state.socket) return;
    setConnection(true);
    try {
      const response = await fetch(api('/api/feed'));
      const feed = await response.json();
      if (socket === state.socket) { state.files = feed.files; state.messages = feed.messages; renderChat(); }
    } catch (_) {}
  });
  socket.addEventListener("message", (event) => {
    if (socket !== state.socket) return;
    const update = JSON.parse(event.data);
    if (update.type === "file" && !state.files.some((item) => item.id === update.data.id)) {
      state.files.push(update.data);
      renderChat();
      if (update.data.sender !== deviceName.value) toast(`${update.data.sender} 发来一个文件`);
    }
    if (update.type === "message" && !state.messages.some((item) => item.id === update.data.id)) {
      state.messages.push(update.data);
      renderChat();
      if (update.data.sender !== deviceName.value) toast(`${update.data.sender} 发来一条文字`);
    }
    if (update.type === "clear") {
      state.files = [];
      state.messages = [];
      renderChat(false);
      toast("会话已清空");
    }
  });
  socket.addEventListener("close", () => {
    if (socket !== state.socket) return;
    setConnection(false);
  });
}

function upload(file) {
  if (!state.ready) return Promise.reject(new Error('请等待主机连接完成'));
  const base = state.base;
  return new Promise((resolve, reject) => {
    const id = `upload-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    $("#uploadQueue").insertAdjacentHTML("beforeend", `<div id="${id}" class="upload-item"><div class="upload-row"><span class="upload-name">正在发送：${escapeHtml(file.name)}</span><span class="percent">0%</span></div><div class="progress"><span style="width:0%"></span></div></div>`);
    const row = document.getElementById(id);
    const request = new XMLHttpRequest();
    const body = new FormData();
    body.append("file", file);
    body.append("sender", deviceName.value);
    request.open("POST", api("/api/files"));
    state.requests.add(request);
    request.addEventListener('loadend', () => state.requests.delete(request));
    request.addEventListener('abort', () => { row.classList.add('failed'); row.querySelector('.upload-name').textContent = '连接已切换，请重新发送：' + file.name; reject(new Error('连接已切换')); });
    request.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) return;
      const percent = Math.round((event.loaded / event.total) * 100);
      row.querySelector(".percent").textContent = `${percent}%`;
      row.querySelector(".progress span").style.width = `${percent}%`;
    });
    request.addEventListener("load", () => {
      if (request.status >= 200 && request.status < 300) {
        const result = JSON.parse(request.responseText);
        if (base !== state.base) { row.remove(); reject(new Error('主机已切换，请核对原主机的接收记录')); return; }
        if (!state.files.some((item) => item.id === result.id)) state.files.push(result);
        renderChat();
        row.remove();
        resolve(result);
      } else {
        row.classList.add("failed");
        reject(new Error("上传失败"));
      }
    });
    request.addEventListener("error", () => {
      row.classList.add("failed");
      reject(new Error("网络中断"));
    });
    request.send(body);
  });
}

async function uploadFiles(files, source = "file") {
  if (!files.length) return;
  if (source === "clipboard") toast(`正在发送 ${files.length} 个剪贴板文件`);
  for (const file of files) {
    try { await upload(file); }
    catch (error) { toast(`${file.name} 发送失败，请重试`); }
  }
}

function clipboardFile(file, index) {
  const extension = (file.type.split("/")[1] || "png").replace("jpeg", "jpg");
  const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
  const label = file.type.startsWith("image/") ? "剪贴板图片" : "剪贴板文件";
  return new File([file], `${label}-${stamp}-${index + 1}.${extension}`, { type: file.type, lastModified: Date.now() });
}

const fileInput = $("#fileInput");
$("#fileButton").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => {
  uploadFiles([...fileInput.files]);
  fileInput.value = "";
});

document.addEventListener("paste", (event) => {
  const files = [...(event.clipboardData?.items || [])]
    .filter((item) => item.kind === "file")
    .map((item) => item.getAsFile())
    .filter(Boolean)
    .map((file, index) => file.name ? file : clipboardFile(file, index));
  if (!files.length) return;
  event.preventDefault();
  uploadFiles(files, "clipboard");
});

let dragDepth = 0;
const chatPanel = $("#chatPanel");
const dropOverlay = $("#dropOverlay");
chatPanel.addEventListener("dragenter", (event) => {
  if (!event.dataTransfer?.types.includes("Files")) return;
  event.preventDefault();
  dragDepth += 1;
  dropOverlay.classList.add("show");
});
chatPanel.addEventListener("dragover", (event) => event.preventDefault());
chatPanel.addEventListener("dragleave", () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) dropOverlay.classList.remove("show");
});
chatPanel.addEventListener("drop", (event) => {
  event.preventDefault();
  dragDepth = 0;
  dropOverlay.classList.remove("show");
  uploadFiles([...event.dataTransfer.files]);
});

$("#messageForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!state.ready) { toast('正在寻找或连接主机，请稍候'); return; }
  const base = state.base;
  const input = $("#messageInput");
  const content = input.value.trim();
  if (!content) return;
  const button = $("#sendButton");
  button.disabled = true;
  button.textContent = "发送中";
  try {
    const response = await fetch(api("/api/messages"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, sender: deviceName.value }),
      signal: AbortSignal.timeout(6000),
    });
    if (!response.ok) throw new Error("发送失败");
    const result = await response.json();
    if (base !== state.base) { toast('连接已切换，文字已保留，请核对原主机记录'); return; }
    if (!state.messages.some((item) => item.id === result.id)) state.messages.push(result);
    input.value = "";
    renderChat();
  } catch (error) {
    toast("发送失败，请重试");
  } finally {
    button.disabled = !state.ready;
    button.textContent = "发送";
    input.focus();
  }
});

$("#messageInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    $("#messageForm").requestSubmit();
  }
});
let imageClickTimer;
function downloadImage(link) {
  const download = document.createElement("a");
  download.href = link.href;
  download.download = link.download;
  download.click();
}

function closeImagePreview() {
  $("#imagePreview").hidden = true;
}

function openImagePreview(link) {
  const preview = $("#imagePreview");
  const image = link.querySelector("img");
  $("#imagePreviewImage").src = image.currentSrc || image.src;
  $("#imagePreviewImage").alt = image.alt;
  preview.dataset.downloadUrl = link.href;
  preview.dataset.downloadName = link.download;
  preview.hidden = false;
  $("#imagePreviewClose").focus();
}

$("#chatList").addEventListener("click", async (event) => {
  const imageLink = event.target.closest(".image-link");
  if (imageLink) {
    event.preventDefault();
    clearTimeout(imageClickTimer);
    imageClickTimer = setTimeout(() => openImagePreview(imageLink), 220);
    return;
  }
  const bubble = event.target.closest(".text-bubble");
  if (!bubble) return;
  await copyText(bubble.dataset.copy);
  toast("文字已复制");
});

$("#chatList").addEventListener("dblclick", (event) => {
  const imageLink = event.target.closest(".image-link");
  if (!imageLink) return;
  event.preventDefault();
  clearTimeout(imageClickTimer);
  downloadImage(imageLink);
});

$("#imagePreviewClose").addEventListener("click", closeImagePreview);
$("#imagePreview").addEventListener("click", (event) => {
  if (event.target === event.currentTarget) closeImagePreview();
});
let previewImageClickTimer;
$("#imagePreviewImage").addEventListener("click", () => {
  clearTimeout(previewImageClickTimer);
  previewImageClickTimer = setTimeout(closeImagePreview, 220);
});
$("#imagePreviewImage").addEventListener("dblclick", () => {
  clearTimeout(previewImageClickTimer);
  downloadImage({ href: $("#imagePreview").dataset.downloadUrl, download: $("#imagePreview").dataset.downloadName });
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("#imagePreview").hidden) closeImagePreview();
});

$("#clearConversation").addEventListener("click", async () => {
  if (!combinedItems().length) {
    toast("当前没有可清理的会话记录");
    return;
  }
  if (!window.confirm("确定清空全部会话记录吗？\n已传文件会保留在原主机中。")) return;
  const button = $("#clearConversation");
  button.disabled = true;
  button.textContent = "清理中";
  try {
    const base = state.base;
    const response = await fetch(api("/api/conversation"), { method: "DELETE" });
    if (!response.ok) throw new Error("清理失败");
    if (base !== state.base) return;
    state.files = [];
    state.messages = [];
    renderChat(false);
    toast("会话已清空，文件仍已保留");
  } catch (error) {
    toast("清理失败，请重试");
  } finally {
    button.disabled = false;
    button.textContent = "清空会话";
  }
});

async function copyAddress() {
  await copyText($("#lanAddress").textContent);
  toast("访问地址已复制");
}
$("#copyAddress").addEventListener("click", copyAddress);
$("#mobileAddress").addEventListener("click", copyAddress);

let networkView = null;
let lastNote = '';
async function networkAction(path, payload = {}) {
  if (state.requests.size) { toast('请等待文件发送完成后再切换主机'); return; }
  if (state.networkBusy) return;
  state.networkBusy = true;
  $('#networkRole').textContent = '正在请求连接…';
  $('#connectHost').disabled = $('#scanNetwork').disabled = true;
  try {
    const response = await fetch(path, {method: 'POST', headers: {'Content-Type':'application/json', 'X-Transfer-Control':'1'}, body: JSON.stringify(payload), signal: AbortSignal.timeout(8000)});
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || '连接失败，请重试');
    $('#networkNote').classList.remove('network-error');
    renderNetwork(result);
  } catch (error) {
    $('#networkNote').textContent = error.message;
    $('#networkNote').classList.add('network-error');
    toast(error.message);
  } finally {
    state.networkBusy = false;
    $('#connectHost').disabled = $('#scanNetwork').disabled = false;
  }
}

function renderNetwork(view) {
  networkView = view;
  if (view.can_control && !localStorage.getItem('landrop-device-name')) deviceName.value = view.name;
  $('#networkRole').textContent = view.role === 'host' ? `本机是主机 · ${view.members.length} 台已加入` : view.role === 'client' ? '已连接主机 · 可双向互传' : '正在搜索主机…';
  $('#scanNetwork').disabled = !view.can_control;
  $('#connectHost').disabled = !view.can_control;
  $('#lanAddress').textContent = view.url;
  $('#storageNote').textContent = view.role === 'client' ? '当前内容保存在所连接的主机。主机离线后，旧文件仍留在原主机。' : '当前会话保存在主机的应用数据目录。所有加入的成员均可收发和查看。';
  if (view.note !== lastNote) {
    $('#networkNote').textContent = view.warning || view.note;
    $('#networkNote').classList.remove('network-error');
    lastNote = view.note;
  }
  const row = (name, address, tag, action = '') => `<div class="peer-row"><div class="peer-copy"><strong>${escapeHtml(name)}</strong><small>${escapeHtml(address.replace('http://',''))}</small></div>${action || `<span class="peer-tag">${tag}</span>`}</div>`;
  let rows = view.addresses.map(ip => row(view.name + ' · 本机', `${ip}:${view.port}`, view.role === 'host' ? '主机' : view.role === 'client' ? '客户端' : '搜索中')).join('');
  rows += view.peers.map(peer => {
    const current = peer.id === view.target_id;
    const action = peer.role === 'host' && !current && view.can_control ? `<button type="button" data-peer="${escapeHtml(peer.url)}">连接</button>` : '';
    return row(peer.name, peer.url, current ? '已连接' : peer.role === 'host' ? '主机' : peer.target_id === view.node_id ? '已加入' : peer.role === 'client' ? '客户端' : '搜索中', action);
  }).join('');
  if (view.role === 'client' && !view.peers.some(p => p.id === view.target_id)) rows += row('当前主机', view.target, '已连接');
  if (view.role === 'host') rows += view.members.filter(m => !view.peers.some(p => p.id === m.id)).map(m => row(m.name, m.ip, '已加入')).join('');
  const focused = document.activeElement?.dataset?.peer;
  if ($('#peerList').innerHTML !== rows) {
    $('#peerList').innerHTML = rows;
    if (focused) [...$('#peerList').querySelectorAll('button')].find(b => b.dataset.peer === focused)?.focus();
  }
  const nextBase = view.role === 'searching' ? null : view.role === 'client' ? view.target : '';
  if (nextBase !== state.base) {
    for (const request of state.requests) request.abort();
    const previous = state.socket;
    state.socket = null;
    previous?.close();
    state.base = nextBase;
    state.files = []; state.messages = [];
    setConnection(false);
    renderChat(false);
    if (nextBase !== null) load();
  } else if (nextBase !== null && !state.ready) load();
}

$('#scanNetwork').addEventListener('click', () => networkAction('/api/network/rescan'));
$('#connectForm').addEventListener('submit', event => { event.preventDefault(); networkAction('/api/network/connect', {address: $('#hostAddress').value}); });
$('#peerList').addEventListener('click', event => { const button = event.target.closest('[data-peer]'); if (button) networkAction('/api/network/connect', {address: button.dataset.peer}); });
async function pollNetwork() {
  try {
    if (!state.networkBusy) {
      const response = await fetch('/api/network', {signal: AbortSignal.timeout(2500)});
      if (!response.ok) throw new Error('本机服务连接失败');
      renderNetwork(await response.json());
    }
  } catch (_) { $('#networkRole').textContent = '本机服务连接失败，正在重试…'; }
  setTimeout(pollNetwork, 1200);
}
setConnection(false);
pollNetwork();
