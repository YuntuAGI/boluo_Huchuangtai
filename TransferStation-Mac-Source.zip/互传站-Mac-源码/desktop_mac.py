"""Mac entry point: shared LAN protocol, menu bar, persistent floating window."""
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import sys
import threading
import time
import traceback

DATA = Path(os.environ.get('TRANSFER_DATA_DIR', str(Path.home() / 'Library/Application Support/互传站')))
DATA.mkdir(parents=True, exist_ok=True)
os.environ['TRANSFER_DATA_DIR'] = str(DATA)


def main():
    lock = (DATA / 'instance.lock').open('a+')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock.seek(0)
        try:
            os.kill(int(lock.read()), signal.SIGUSR1)
        except (ValueError, ProcessLookupError):
            pass
        return
    lock.seek(0)
    lock.truncate()
    lock.write(str(os.getpid()))
    lock.flush()
    reopen = threading.Event()
    signal.signal(signal.SIGUSR1, lambda *_: reopen.set())
    import uvicorn
    import server as service
    from network import Network
    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    for port in range(8787, 8798):
        try:
            listener.bind(('0.0.0.0', port))
            break
        except OSError:
            if port == 8797:
                raise RuntimeError('8787–8797 端口均被占用，请退出旧版互传站后重试。')
    server = uvicorn.Server(uvicorn.Config(service.app, log_config=None, access_log=False,
        ws='websockets-sansio', timeout_graceful_shutdown=3))
    worker = threading.Thread(target=server.run, kwargs={'sockets': [listener]}, daemon=True)
    worker.start()
    for _ in range(100):
        if server.started:
            break
        if not worker.is_alive():
            raise RuntimeError('传输服务启动失败。')
        time.sleep(.05)
    if not server.started:
        raise RuntimeError('传输服务启动超时。')
    url = f'http://127.0.0.1:{port}'
    network = Network(port, DATA, service.local_ip(), int(os.environ.get('TRANSFER_DISCOVERY_PORT', '48787')))
    service.network = network
    network.start()
    (DATA / 'endpoint.txt').write_text(url)
    stopped = threading.Event()

    def shutdown():
        if stopped.is_set():
            return
        stopped.set()
        network.stop()
        server.should_exit = True
        worker.join(timeout=5)
        listener.close()

    if '--headless-test' in sys.argv:
        signal.signal(signal.SIGTERM, lambda *_: stopped.set())
        try:
            while not stopped.wait(.2) and worker.is_alive():
                pass
        finally:
            stopped.clear()
            shutdown()
        return

    import webview
    import AppKit
    from Foundation import NSObject, NSTimer
    from PyObjCTools import AppHelper
    webview.settings['ALLOW_DOWNLOADS'] = True
    webview.settings['ALLOW_FILE_URLS'] = False
    webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER'] = False

    class Bridge:
        def show_main(self):
            AppHelper.callAfter(controller.openMain_, None)
        def show_floating(self):
            AppHelper.callAfter(controller.showFloat_, None)

    bridge = Bridge()
    main_window = webview.create_window('互传站', url, width=1080, height=740,
        min_size=(900, 600), background_color='#ededed', text_select=True, js_api=bridge)
    floating = webview.create_window('互传站 · 悬浮', url + '/?mini=1', width=370, height=460,
        min_size=(340, 380), background_color='#ededed', text_select=True, on_top=True, js_api=bridge)

    class Controller(NSObject):
        def openMain_(self, sender):
            main_window.native.makeKeyAndOrderFront_(None)
            AppKit.NSApp.activateIgnoringOtherApps_(True)
        def showFloat_(self, sender):
            floating.native.makeKeyAndOrderFront_(None)
            AppKit.NSApp.activateIgnoringOtherApps_(True)
            self.floatItem.setState_(1)
        def toggleFloat_(self, sender):
            if floating.native.isVisible():
                floating.native.orderOut_(None)
                self.floatItem.setState_(0)
            else:
                self.showFloat_(sender)
        def copyAddress_(self, sender):
            pasteboard = AppKit.NSPasteboard.generalPasteboard()
            pasteboard.clearContents()
            pasteboard.setString_forType_(network.snapshot()['url'], AppKit.NSPasteboardTypeString)
        def showFiles_(self, sender):
            AppKit.NSWorkspace.sharedWorkspace().openFile_(str(DATA / 'files'))
        def quit_(self, sender):
            AppKit.NSApp.terminate_(None)
        def tick_(self, timer):
            if reopen.is_set():
                reopen.clear()
                self.openMain_(None)
            view = network.snapshot()
            label = '正在搜索主机' if view['role'] == 'searching' else '已连接主机' if view['role'] == 'client' else f"本机主机 · {len(view['members'])} 台已加入"
            self.statusLine.setTitle_(label)
            self.status.button().setToolTip_('互传站 · ' + label)

    controller = Controller.alloc().init()

    def configure():
        from webview.platforms.cocoa import BrowserView
        import WebKit
        class TransferBrowserDelegate(BrowserView.BrowserDelegate):
            def webView_decidePolicyForNavigationResponse_decisionHandler_(self, view, response, handler):
                headers = response.response().allHeaderFields() or {}
                disposition = next((str(v) for k, v in headers.items() if str(k).lower() == 'content-disposition'), '')
                if disposition.lower().startswith('attachment'):
                    handler(WebKit.WKNavigationResponsePolicyDownload)
                else:
                    super().webView_decidePolicyForNavigationResponse_decisionHandler_(view, response, handler)
            def webView_navigationResponse_didBecomeDownload_(self, view, response, download):
                download.setDelegate_(BrowserView.DownloadDelegate.alloc().init().retain())
        # WebKit ignores the HTML download attribute on another LAN origin.
        # Respect the server's attachment header, including renderable text/images.
        for window in (main_window, floating):
            browser = BrowserView.instances[window.uid]
            browser._browserDelegate = TransferBrowserDelegate.alloc().init()
            browser.webview.setUIDelegate_(browser._browserDelegate)
            browser.webview.setNavigationDelegate_(browser._browserDelegate)
        original = AppKit.NSApp.delegate().__class__
        # Retain pywebview's launch behavior while respecting macOS Quit/log out.
        class ResidentDelegate(original):
            def applicationShouldTerminateAfterLastWindowClosed_(self, app):
                return False
            def applicationShouldHandleReopen_hasVisibleWindows_(self, app, visible):
                controller.openMain_(None)
                return True
            def applicationShouldTerminate_(self, app):
                shutdown()
                AppKit.NSStatusBar.systemStatusBar().removeStatusItem_(controller.status)
                return AppKit.NSTerminateNow
        controller.delegate = ResidentDelegate.alloc().init()
        AppKit.NSApp.setDelegate_(controller.delegate)
        controller.status = AppKit.NSStatusBar.systemStatusBar().statusItemWithLength_(AppKit.NSVariableStatusItemLength)
        button = controller.status.button()
        icon = AppKit.NSImage.imageWithSystemSymbolName_accessibilityDescription_('arrow.left.arrow.right', '互传站')
        icon.setTemplate_(True)
        button.setImage_(icon)
        menu = AppKit.NSMenu.alloc().init()
        def item(title, action=None, key=''):
            value = AppKit.NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, action, key)
            if action:
                value.setTarget_(controller)
            menu.addItem_(value)
            return value
        controller.statusLine = item('正在搜索主机')
        menu.addItem_(AppKit.NSMenuItem.separatorItem())
        item('打开互传站', 'openMain:', 'o')
        controller.floatItem = item('显示悬浮小窗', 'toggleFloat:', 'f')
        controller.floatItem.setState_(1)
        item('复制互传地址', 'copyAddress:')
        item('打开本机接收文件夹', 'showFiles:')
        menu.addItem_(AppKit.NSMenuItem.separatorItem())
        item('退出互传站', 'quit:', 'q')
        controller.status.setMenu_(menu)
        main_window.native.setFrameAutosaveName_('TransferStationMain')
        float_native = floating.native
        float_native.setLevel_(AppKit.NSFloatingWindowLevel)
        float_native.setHidesOnDeactivate_(False)
        float_native.setCollectionBehavior_(AppKit.NSWindowCollectionBehaviorCanJoinAllSpaces | AppKit.NSWindowCollectionBehaviorFullScreenAuxiliary)
        screen = AppKit.NSScreen.mainScreen().visibleFrame()
        saved = float_native.setFrameUsingName_('TransferStationFloat')
        if not saved:
            float_native.setFrameOrigin_((screen.origin.x + screen.size.width - 390, screen.origin.y + screen.size.height - 490))
        float_native.setFrameAutosaveName_('TransferStationFloat')
        float_native.standardWindowButton_(AppKit.NSWindowZoomButton).setHidden_(True)
        float_native.orderFrontRegardless()
        controller.timer = NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(1, controller, 'tick:', None, True)
        ready.set()

    def hide_main():
        AppHelper.callAfter(main_window.native.orderOut_, None)
        return False
    def hide_float():
        AppHelper.callAfter(floating.native.orderOut_, None)
        AppHelper.callAfter(controller.floatItem.setState_, 0)
        return False
    main_window.events.closing += hide_main
    floating.events.closing += hide_float
    ready = threading.Event()

    def initialize():
        main_window.events.shown.wait(15)
        floating.events.shown.wait(15)
        AppHelper.callAfter(configure)
        if '--self-test' in sys.argv:
            from selftest import check_gui
            check_gui(main_window, floating, controller, ready, DATA, url, network, shutdown)

    try:
        webview.start(initialize, gui='cocoa', private_mode=False,
            storage_path=str(DATA / 'window-profile'),
            localization={'global.saveFile': '保存文件', 'global.openFile': '选择文件',
                          'global.quit': '退出互传站', 'global.quitConfirmation': '确定退出互传站？'})
    finally:
        shutdown()
        lock.close()


if __name__ == '__main__':
    log = (DATA / 'desktop.log').open('a', encoding='utf-8', buffering=1)
    if getattr(sys, 'frozen', False):
        sys.stdout = sys.stderr = log
    try:
        main()
    except Exception as error:
        traceback.print_exc(file=log)
        if '--headless-test' not in sys.argv:
            import AppKit
            alert = AppKit.NSAlert.alloc().init()
            alert.setMessageText_('互传站启动失败')
            alert.setInformativeText_(str(error) + '\n日志：' + str(DATA / 'desktop.log'))
            alert.runModal()
        raise
