# Build on Apple Silicon; Python 3.12. No user data is bundled.
a = Analysis(['desktop_mac.py'], pathex=[], binaries=[],
    datas=[('static', 'static')],
    hiddenimports=['webview.platforms.cocoa', 'uvicorn.logging', 'uvicorn.loops.auto',
      'uvicorn.protocols.http.auto', 'uvicorn.protocols.http.h11_impl',
      'uvicorn.protocols.websockets.websockets_sansio_impl', 'uvicorn.lifespan.on'],
    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=['tkinter'], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='互传站', debug=False,
    bootloader_ignore_signals=False, strip=False, upx=False, console=False,
    target_arch='arm64', codesign_identity=None, entitlements_file=None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='互传站')
app = BUNDLE(coll, name='互传站.app', icon='app.icns', bundle_identifier='local.transferstation.mac',
    info_plist={'CFBundleDisplayName': '互传站', 'CFBundleShortVersionString': '1.0.0',
      'CFBundleVersion': '1', 'LSMinimumSystemVersion': '14.0',
      'NSHighResolutionCapable': True,
      'NSLocalNetworkUsageDescription': '互传站需要在同一局域网发现设备、互传文字和文件。',
      'NSAppTransportSecurity': {'NSAllowsArbitraryLoads': True, 'NSAllowsLocalNetworking': True}})
