"""Exercise the actual Mac windows against isolated data (use --self-test)."""
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback
from urllib.request import urlopen


def check_gui(main, mini, controller, ready, data, url, network, shutdown):
    import AppKit
    from PyObjCTools import AppHelper
    from webview.platforms.cocoa import BrowserView
    def native(fn):
        event = threading.Event()
        result = []
        def run():
            try:
                result.append(fn())
            except Exception as error:
                result.append(error)
            finally:
                event.set()
        AppHelper.callAfter(run)
        assert event.wait(10), 'Native action timeout'
        if isinstance(result[0], Exception):
            raise result[0]
        return result[0]
    def until(fn, seconds=20):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if fn():
                return
            time.sleep(.15)
        raise AssertionError('Timed out waiting for UI')
    def capture(window, name):
        done = threading.Event()
        errors = []
        def shot():
            view = BrowserView.instances[window.uid].webview
            def complete(image, error):
                if error:
                    errors.append(str(error))
                else:
                    rep = AppKit.NSBitmapImageRep.imageRepWithData_(image.TIFFRepresentation())
                    rep.representationUsingType_properties_(AppKit.NSBitmapImageFileTypePNG, {}).writeToFile_atomically_(str(data / name), True)
                done.set()
            view.takeSnapshotWithConfiguration_completionHandler_(None, complete)
        native(shot)
        assert done.wait(10) and not errors, errors
    report = {}
    try:
        assert ready.wait(20), 'Native setup failed'
        for window in (main, mini):
            until(lambda: window.evaluate_js("document.querySelector('#onlineLabel').textContent === '在线'"))
        report['both_windows_connected'] = True
        assert main.evaluate_js("""(() => {const s='a" data-bad="x'; const d=document.createElement('div'); d.innerHTML=textBubble({content:s}); return d.firstElementChild.dataset.copy===s && !d.firstElementChild.hasAttribute('data-bad');})()""")
        report['attribute_escaping'] = True
        main.evaluate_js("document.querySelector('#messageInput').value='Mac 互传测试：你好';document.querySelector('#messageForm').requestSubmit();")
        until(lambda: mini.evaluate_js("document.querySelector('#chatList').textContent.includes('Mac 互传测试：你好')"))
        mini.evaluate_js("document.querySelector('#messageInput').value='来自悬浮小窗';document.querySelector('#messageForm').requestSubmit();")
        until(lambda: main.evaluate_js("document.querySelector('#chatList').textContent.includes('来自悬浮小窗')"))
        report['main_and_floating_send_receive'] = True
        mini.evaluate_js("upload(new File(['mac-transfer-content'], '中文文件.txt', {type:'text/plain'}));")
        until(lambda: main.evaluate_js("document.querySelector('#chatList').textContent.includes('中文文件.txt')"))
        active = network.target or url
        feed = json.load(urlopen(active + '/api/feed'))
        file = next(x for x in feed['files'] if x['name'] == '中文文件.txt')
        assert urlopen(active + file['download_url']).read() == b'mac-transfer-content'
        report['unicode_upload_and_download_bytes'] = True
        # Exercise the real WebKit download and native save panel.
        from Foundation import NSURL
        download_dir = data / 'saved'
        download_dir.mkdir(exist_ok=True)
        main.evaluate_js("document.querySelector('.file-card').click()")
        def save_panel():
            return next((w for w in AppKit.NSApp.windows() if isinstance(w, AppKit.NSSavePanel) and w.isVisible()), None)
        until(lambda: native(save_panel) is not None)
        def dismiss_save():
            panel = save_panel()
            AppKit.NSApp.stopModalWithCode_(AppKit.NSModalResponseCancel)
            panel.orderOut_(None)
        native(dismiss_save)
        report['native_save_dialog_presented_and_cancelled'] = True
        # Send a PNG through the actual system clipboard and WebKit paste responder.
        import base64
        from Foundation import NSData
        png = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1sAAAAASUVORK5CYII=')
        native(lambda: controller.showFloat_(None))
        mini.evaluate_js("document.querySelector('#messageInput').focus()")
        def paste_image():
            pb = AppKit.NSPasteboard.generalPasteboard()
            pb.clearContents()
            pb.setData_forType_(NSData.dataWithBytes_length_(png, len(png)), AppKit.NSPasteboardTypePNG)
            AppKit.NSApp.sendAction_to_from_('paste:', None, None)
        # Preserve the user's clipboard across this automatic check.
        def backup_clipboard():
            pb = AppKit.NSPasteboard.generalPasteboard()
            return [(t, bytes(pb.dataForType_(t))) for t in pb.types() if pb.dataForType_(t) is not None]
        backup = native(backup_clipboard)
        try:
            native(paste_image)
            until(lambda: any(x['type'].startswith('image/') for x in json.load(urlopen(active + '/api/feed'))['files']))
            report['native_clipboard_image_paste'] = True
        finally:
            def restore_clipboard():
                pb = AppKit.NSPasteboard.generalPasteboard()
                pb.clearContents()
                for kind, value in backup:
                    pb.setData_forType_(NSData.dataWithBytes_length_(value, len(value)), kind)
            native(restore_clipboard)
        report['role'] = network.role
        for window in (main, mini):
            assert window.evaluate_js('document.documentElement.scrollWidth <= innerWidth')
        report['no_horizontal_overflow'] = True
        assert native(lambda: mini.native.level()) == AppKit.NSFloatingWindowLevel
        assert native(lambda: mini.native.collectionBehavior()) & AppKit.NSWindowCollectionBehaviorCanJoinAllSpaces
        report['floating_level_and_all_spaces'] = True
        native(lambda: controller.openMain_(None))
        time.sleep(.5)
        capture(main, 'main.png')
        native(lambda: controller.showFloat_(None))
        time.sleep(.5)
        capture(mini, 'floating.png')
        native(lambda: main.native.performClose_(None))
        until(lambda: not native(lambda: main.native.isVisible()))
        assert json.load(urlopen(active + '/api/status'))['ok']
        report['close_hides_service_stays_online'] = True
        native(lambda: controller.openMain_(None))
        assert native(lambda: main.native.isVisible())
        report['menu_restores_window'] = True
        native(lambda: controller.toggleFloat_(None))
        assert not native(lambda: mini.native.isVisible())
        native(lambda: controller.toggleFloat_(None))
        assert native(lambda: mini.native.isVisible())
        report['floating_toggle'] = True
        native(lambda: main.native.performClose_(None))
        until(lambda: not native(lambda: main.native.isVisible()))
        command = [sys.executable] if getattr(sys, 'frozen', False) else [sys.executable, str(Path(__file__).with_name('desktop_mac.py'))]
        subprocess.run(command, timeout=15, check=True)
        until(lambda: native(lambda: main.native.isVisible()))
        report['duplicate_launch_restores_existing_window'] = True
        report['passed'] = True
    except Exception:
        report['error'] = traceback.format_exc()
    finally:
        (data / 'self-test.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
        AppHelper.callAfter(controller.quit_, None)
