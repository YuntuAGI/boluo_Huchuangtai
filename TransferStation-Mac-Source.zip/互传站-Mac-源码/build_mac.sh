#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
if [ ! -d .venv ]; then "$PYTHON" -m venv .venv; fi
.venv/bin/pip install -r requirements-mac-lock.txt
.venv/bin/python -m PyInstaller --noconfirm --clean 互传站.spec
xattr -d com.apple.FinderInfo 'dist/互传站.app' 2>/dev/null || true
codesign --verify --deep --strict 'dist/互传站.app'
printf '\n构建完成：dist/互传站.app\n'
