"""Native Windows notification icon; all callbacks run on the UI thread."""
from System.Drawing import Icon
from System.Windows.Forms import (NotifyIcon, ContextMenuStrip, ToolStripMenuItem,
    ToolStripSeparator, FormWindowState, CloseReason, Timer, ToolTipIcon)


class Tray:
    def __init__(self, form, icon_path, network, kernel, show_event):
        self.form, self.network = form, network
        self.kernel, self.show_event = kernel, show_event
        self.exiting = self.disposed = self.notified = False
        self.icon_image = Icon(str(icon_path))
        self.icon = NotifyIcon()
        self.icon.Icon = self.icon_image
        self.icon.Text = '互传站 · 正在连接'
        self.menu = ContextMenuStrip()
        self.status_item = ToolStripMenuItem('正在连接…')
        self.status_item.Enabled = False
        self.open_item = ToolStripMenuItem('打开互传站')
        self.open_item.Click += self.show
        self.exit_item = ToolStripMenuItem('退出互传站')
        self.exit_item.Click += self.quit
        self.menu.Items.Add(self.status_item)
        self.menu.Items.Add(ToolStripSeparator())
        self.menu.Items.Add(self.open_item)
        self.menu.Items.Add(self.exit_item)
        self.icon.ContextMenuStrip = self.menu
        self.icon.DoubleClick += self.show
        self.icon.Visible = True
        self.form.FormClosing += self.closing
        self.form.FormClosed += self.dispose
        self.timer = Timer()
        self.timer.Interval = 500
        self.timer.Tick += self.tick
        self.timer.Start()

    def show(self, *_):
        if self.exiting:
            return
        self.form.Show()
        if self.form.WindowState == FormWindowState.Minimized:
            self.form.WindowState = FormWindowState.Normal
        self.form.Activate()
        self.form.BringToFront()

    def closing(self, sender, args):
        # A real quit, sign-out or shutdown must not be converted into a hidden app.
        if self.exiting or args.CloseReason != CloseReason.UserClosing:
            return
        args.Cancel = True
        self.form.Hide()
        if not self.notified:
            self.icon.ShowBalloonTip(2500, '互传站仍在后台运行',
                '双击托盘图标重新打开；右键选择“退出互传站”可彻底关闭。', ToolTipIcon.Info)
            self.notified = True

    def tick(self, *_):
        if self.kernel.WaitForSingleObject(self.show_event, 0) == 0:
            self.show()
        state = self.network.snapshot()
        role = {'host': '本机主机', 'client': '已连接主机', 'searching': '正在搜索主机'}[state['role']]
        text = f'互传站 · {role}'
        if text != self.icon.Text:
            self.icon.Text = text
            self.status_item.Text = role

    def quit(self, *_):
        self.exiting = True
        self.form.Close()

    def dispose(self, *_):
        if self.disposed:
            return
        self.timer.Stop()
        self.timer.Dispose()
        self.icon.Visible = False
        self.icon.Dispose()
        self.menu.Dispose()
        self.icon_image.Dispose()
        self.disposed = True
