﻿param([string]$Python = 'python')
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
        & $Python -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw 'Unable to create Python environment' }
    }
    $buildPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    & $buildPython -m pip install -r requirements-windows-lock.txt
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed' }
    & $buildPython -m PyInstaller --noconfirm --onefile --windowed `
        --name '互传站_后台常驻版' --icon "$PSScriptRoot\app.ico" `
        --add-data "$PSScriptRoot\static;static" --add-data "$PSScriptRoot\app.ico;." `
        --hidden-import uvicorn.protocols.websockets.websockets_sansio_impl `
        --collect-all webview --distpath dist --workpath build --specpath . desktop.py
    if ($LASTEXITCODE -ne 0) { throw 'EXE build failed' }
} finally {
    Pop-Location
}
