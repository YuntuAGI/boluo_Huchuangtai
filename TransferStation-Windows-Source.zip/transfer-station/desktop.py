"""Windows desktop entry point; never starts an external browser."""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
import traceback

TITLE = "互传站 · 桌面版"
ROOT = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent
DATA = Path(os.environ.get("TRANSFER_DATA_DIR", str(ROOT / "data")))


def main():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CreateEventW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.CreateEventW.restype = wintypes.HANDLE
    kernel.OpenEventW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.OpenEventW.restype = wintypes.HANDLE
    kernel.SetEvent.argtypes = [wintypes.HANDLE]
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    testing = '--headless-test' in sys.argv or '--self-test' in sys.argv
    mutex_name = "Local\\TransferStationDesktopV2"
    if testing:
        import hashlib
        mutex_name += hashlib.sha256(str(DATA).encode()).hexdigest()[:12]
    mutex = kernel.CreateMutexW(None, False, mutex_name)
    if not mutex:
        raise ctypes.WinError(ctypes.get_last_error())
    if ctypes.get_last_error() == 183:
        event = kernel.OpenEventW(2, False, mutex_name + '_Show')
        if event:
            kernel.SetEvent(event)
            kernel.CloseHandle(event)
            kernel.CloseHandle(mutex)
            return
        user = ctypes.windll.user32
        user.FindWindowW.restype = wintypes.HWND
        user.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
        handle = user.FindWindowW(None, TITLE)
        if handle:
            user.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
            user.SetForegroundWindow.argtypes = [wintypes.HWND]
            user.ShowWindow(handle, 9)
            user.SetForegroundWindow(handle)
        kernel.CloseHandle(mutex)
        return

    DATA.mkdir(parents=True, exist_ok=True)
    os.environ["TRANSFER_DATA_DIR"] = str(DATA)
    log = (DATA / "desktop.log").open("a", encoding="utf-8", buffering=1)
    if sys.stdout is None:
        sys.stdout = log
    if sys.stderr is None:
        sys.stderr = log

    import uvicorn
    import webview
    import server as service
    from network import Network
    app = service.app

    # Reserve the port before starting the server, so another instance cannot race us.
    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
    for port in range(8787, 8798):
        try:
            listener.bind(("0.0.0.0", port))
            break
        except OSError:
            if port == 8797:
                raise RuntimeError("8787–8797 端口均被占用，请关闭旧版互传站后重试。")
    server = uvicorn.Server(uvicorn.Config(app, log_config=None, access_log=False,
        ws="websockets-sansio", timeout_graceful_shutdown=5))
    worker = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=True)
    worker.start()
    for _ in range(100):
        if server.started:
            break
        if not worker.is_alive():
            raise RuntimeError("传输服务未能启动，请查看 data/desktop.log。")
        time.sleep(.05)
    if not server.started:
        raise RuntimeError("传输服务启动超时，请重新打开客户端。")

    url = f"http://127.0.0.1:{port}"
    network = Network(port, DATA, service.local_ip(), int(os.environ.get('TRANSFER_DISCOVERY_PORT', '48787')))
    service.network = network
    network.start()
    if '--headless-test' in sys.argv:
        (DATA / 'endpoint.txt').write_text(url)
        try:
            while worker.is_alive():
                time.sleep(.2)
        finally:
            network.stop()
            server.should_exit = True
        return
    webview.settings["ALLOW_DOWNLOADS"] = True
    webview.settings["ALLOW_FILE_URLS"] = False
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = False
    window = webview.create_window(TITLE, url, width=1180, height=820,
        min_size=(900, 600), background_color="#ededed", text_select=True)
    window.events.closed += lambda: setattr(server, "should_exit", True)
    show_event = kernel.CreateEventW(None, False, False, mutex_name + '_Show')
    if not show_event:
        raise ctypes.WinError(ctypes.get_last_error())
    tray_holder = []

    def check():
        """Exercise the real packaged window without touching the user's history."""
        result = {"port": port}
        try:
            for _ in range(100):
                ready = window.evaluate_js("document.querySelector('#onlineLabel')?.textContent === '在线'")
                if ready:
                    break
                time.sleep(.15)
            assert ready, "Desktop UI did not connect"
            result["ui_connected"] = True
            window.evaluate_js("document.querySelector('#messageInput').value='桌面窗口发送测试';document.querySelector('#messageForm').requestSubmit();")
            for _ in range(50):
                sent = window.evaluate_js("document.querySelector('#chatList').textContent.includes('桌面窗口发送测试')")
                if sent:
                    break
                time.sleep(.1)
            assert sent, "Message was not rendered"
            result["message_sent_in_window"] = True
            window.evaluate_js("upload(new File(['desktop-test-content'], 'desktop-test.txt', {type:'text/plain'}));")
            for _ in range(50):
                uploaded = window.evaluate_js("document.querySelector('#chatList').textContent.includes('desktop-test.txt')")
                if uploaded:
                    break
                time.sleep(.1)
            assert uploaded, "File upload failed"
            result["upload_in_window"] = True
            from urllib.request import urlopen
            active_url = network.target or url
            feed = json.load(urlopen(active_url + "/api/feed"))
            item = next(x for x in feed["files"] if x["name"] == "desktop-test.txt")
            assert urlopen(active_url + item["download_url"]).read() == b"desktop-test-content"
            result['role'] = network.role
            result['target'] = network.target
            result['peers'] = len(network.snapshot()['peers'])
            result["download_bytes_match"] = True
            result["no_horizontal_overflow"] = window.evaluate_js("document.documentElement.scrollWidth <= innerWidth")
            assert result["no_horizontal_overflow"]
            result["renderer"] = webview.renderer
            # Capture the actual embedded renderer, not a separate browser preview.
            from System import Action
            from System.IO import FileStream, FileMode
            from Microsoft.Web.WebView2.Core import CoreWebView2CapturePreviewImageFormat
            widths = []
            for width in (320, 375, 414, 768, 900, 1180):
                commands = []
                params = json.dumps(dict(width=width, height=800, deviceScaleFactor=1, mobile=False))
                window.native.Invoke(Action(lambda: commands.append(
                    window.native.browser.webview.CoreWebView2.CallDevToolsProtocolMethodAsync(
                        'Emulation.setDeviceMetricsOverride', params))))
                commands[0].Wait(5000)
                time.sleep(.1)
                fits = window.evaluate_js('document.documentElement.scrollWidth <= innerWidth')
                assert fits, f'Horizontal overflow at {width}'
                widths.append(width)
            commands = []
            window.native.Invoke(Action(lambda: commands.append(
                window.native.browser.webview.CoreWebView2.CallDevToolsProtocolMethodAsync(
                    'Emulation.clearDeviceMetricsOverride', '{}'))))
            commands[0].Wait(5000)
            result['responsive_widths'] = widths
            time.sleep(.2)
            stream = FileStream(str(DATA / "window.png"), FileMode.Create)
            capture = []
            window.native.Invoke(Action(lambda: capture.append(
                window.native.browser.webview.CoreWebView2.CapturePreviewAsync(
                    CoreWebView2CapturePreviewImageFormat.Png, stream))))
            capture[0].Wait(10000)
            stream.Close()
            tray = tray_holder[0]
            assert tray.icon.Visible
            window.native.Invoke(Action(window.native.Close))
            time.sleep(.3)
            assert not window.native.Visible, 'Close did not hide window'
            assert tray.icon.Visible, 'Tray icon disappeared while hidden'
            assert json.load(urlopen(active_url + '/api/status'))['ok']
            from network import request_json
            request_json(active_url + '/api/messages', {'content': '后台仍可接收', 'sender': '后台测试'})
            result['close_hides_and_background_transfer_works'] = True
            window.native.Invoke(Action(tray.open_item.PerformClick))
            assert window.native.Visible, 'Tray open did not restore window'
            result['tray_menu_restores_window'] = True
            window.native.Invoke(Action(window.native.Close))
            import subprocess
            duplicate_command = [sys.executable, '--self-test'] if getattr(sys, 'frozen', False) else [sys.executable, str(Path(__file__)), '--self-test']
            duplicate = subprocess.Popen(duplicate_command, creationflags=subprocess.CREATE_NO_WINDOW)
            assert duplicate.wait(timeout=15) == 0
            for _ in range(30):
                if window.native.Visible:
                    break
                time.sleep(.1)
            assert window.native.Visible, 'Duplicate launch did not restore hidden window'
            result['duplicate_launch_restores_hidden_window'] = True
            result["passed"] = True
        except Exception:
            result["error"] = traceback.format_exc()
        finally:
            (DATA / "self-test.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            window.native.Invoke(Action(tray_holder[0].exit_item.PerformClick))

    def initialize():
        from System import Action
        from tray import Tray
        try:
            window.events.shown.wait(15)
            icon_path = Path(getattr(sys, '_MEIPASS', Path(__file__).parent)) / 'app.ico'
            window.native.Invoke(Action(lambda: tray_holder.append(
                Tray(window.native, icon_path, network, kernel, show_event))))
            if '--self-test' in sys.argv:
                check()
        except Exception:
            (DATA / 'tray-error.txt').write_text(traceback.format_exc(), encoding='utf-8')
            if tray_holder:
                window.native.Invoke(Action(tray_holder[0].quit))
            else:
                window.destroy()

    try:
        webview.start(initialize,
            gui="edgechromium", private_mode=False, storage_path=str(DATA / "window-profile"),
            localization={"global.saveFile": "保存文件", "global.openFile": "选择文件",
                          "global.quitConfirmation": "确定关闭互传站？"})
    finally:
        network.stop()
        server.should_exit = True
        worker.join(timeout=8)
        listener.close()
        kernel.CloseHandle(show_event)
        kernel.CloseHandle(mutex)
        if '--self-test' in sys.argv and (DATA / 'self-test.json').exists():
            result = json.loads((DATA / 'self-test.json').read_text(encoding='utf-8'))
            result['tray_disposed_after_exit'] = bool(tray_holder and tray_holder[0].disposed)
            result['service_stopped_after_exit'] = not worker.is_alive()
            result['passed'] = result.get('passed', False) and result['tray_disposed_after_exit'] and result['service_stopped_after_exit']
            (DATA / 'self-test.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        try:
            DATA.mkdir(parents=True, exist_ok=True)
            (DATA / "startup-error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        except OSError:
            pass
        ctypes.windll.user32.MessageBoxW(None,
            f"启动失败：{exc}\n\n请确认文件夹可写，并已安装 Microsoft Edge WebView2 Runtime。", TITLE, 0x10)
        sys.exit(1)
