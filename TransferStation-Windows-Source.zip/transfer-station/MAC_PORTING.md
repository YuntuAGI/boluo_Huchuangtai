# Mac 移植交接

目标：保留现有自动组网和传输协议，在 Mac 上做独立应用窗口和菜单栏常驻图标。
本包未实现 Mac 入口，也未在 Mac 上安装依赖或验证打包。以下内容以当前源码为准。

## 可以复用

- `static/`：界面、发现列表、连接操作、文件上传、图片粘贴和聊天。
- `server.py`：FastAPI 路由、持久化、WebSocket 消息广播；需调整下述路径和 IP 获取细节。
- `network.py`：Python 标准库实现的 UDP 发现及主机选择。仍需在 Mac 多网卡与实际网络中测试。

## 必须替换的 Windows 部分

1. **桌面入口 `desktop.py`**
   - `ctypes.WinDLL('kernel32')`、Mutex、命名 Event、`FindWindowW`、`ShowWindow`、`MessageBoxW` 都是 Windows 专用。
   - 改成 Mac 上的单实例及窗口恢复方式；保留“再打开一次应用，唤回现有窗口”的行为。
   - `socket.SO_EXCLUSIVEADDRUSE` 需要替换为适合 Mac 的端口绑定方式，仍应先绑定端口再启动服务，防止并发抢占。
   - `webview.start(gui='edgechromium')` 是当前 Windows 后端配置，Mac 入口需要改用适合 Mac 的后端。
   - 代码中的 .NET 截图、自检窗口句柄和进程标志不能直接沿用。

2. **托盘 `tray.py`**
   - 目前依赖 `System.Windows.Forms`、`System.Drawing` 和 Windows 命名事件，需替换为 Mac 菜单栏图标实现。
   - 保持操作含义：关闭窗口时应用仍运行；菜单“打开互传站”恢复窗口；菜单“退出互传站”才停止网络与服务并移除图标。
   - Mac 退出、注销和关机不能被“关闭隐藏”逻辑拦住。

3. **IP 与网络适配器**
   - `server.py:local_ip()` 优先执行 Windows 的 `ipconfig`，然后通过 UDP socket 和主机名获得回退地址。
   - Mac 应使用本机网卡信息选取可访问的 LAN 地址，核对 VPN、虚拟网卡和有线／Wi-Fi 并存时的结果。
   - `network.py` 会加入组播并发送广播；需要验证 Mac 防火墙及网络权限对收发的影响。

4. **数据与资源路径**
   - 当前冻结程序使用 EXE 同级 `data/`，不要照搬为 `.app` 包内写入。
   - 建议将数据目录设为 `~/Library/Application Support/互传站/`，并在导入 `server.py` 前设置 `TRANSFER_DATA_DIR`。
   - 打包静态文件，并正确找到只读资源目录；窗口状态／浏览器配置和传输文件都要放在可写目录。
   - 避免把用户历史记录、缓存和 `device-id.txt` 当成发布资源发给其他用户。

5. **图标与测试**
   - `app.ico` 是 Windows 图标。可用 `make_icon.py` 的绘图逻辑生成适合 Mac 的图标资源。
   - `test_network.py` 中的 `taskkill`、`CREATE_NO_WINDOW` 是 Windows 专用，需替换进程启动和清理实现。
   - `desktop.py` 的 `--self-test` 使用 WebView2/.NET 及 Windows 进程恢复逻辑，需单独适配。

## 依赖

以 `requirements.txt` 的应用依赖为起点，在 Mac 的独立环境中安装并验证兼容性。
`requirements-windows-lock.txt` 是 Windows 的完整环境快照，包含 Windows 专用依赖，不应直接作为 Mac 的锁定依赖文件。
`pillow` 只用于重做图标，`pyinstaller` 等属于打包工具。Mac 构建与发布需要在 Mac 环境中完成并实测。

## Windows/Mac 互通协议不要改错

- 协议标识：`transfer-station/2`。
- UDP 发现端口：`48787`。组播：`239.255.87.87`；同时使用局域网广播；组播 TTL 为 1。
- UDP 消息字段：`protocol`、`id`、`name`、`port`、`role`、`target_id`。IP 取自收到数据包的源地址，不信任报文中的自报 IP。
- 节点 ID 是 32 位十六进制字符串；角色是 `searching`、`host`、`client`。
- HTTP 默认 8787，端口被占用时尝试至 8797。
- 状态 `/api/status`；加入请求 `POST /api/network/join`；发现列表 `/api/network`。
- 数据接口 `/api/feed`、`/api/messages`、`/api/files`、`/api/files/{id}`；实时事件 `/api/live`。
- 自动加入当前是“请求后自动接入”，不是主机人工审批。
- 每个桌面端打开自己的本地界面；加入主机后，界面通过当前主机地址收发数据。
- 连接切换接口仅允许本机操作，需保持回环地址、Origin 和 `X-Transfer-Control` 检查。
- 不要把会话接替误改成文件迁移：原记录继续保存在原主机，新主机不自动合并旧数据。

## Mac 验收清单

- 第一台成为主机，第二台自动加入；Windows 与 Mac 可以互相发现和连接。
- 同时启动时能选出一个主机；自动发现被阻止时手动 IP 仍可在网络可达条件下连接。
- 双向文字、文件、拖放、剪贴板图片、中文文件名、文件保存对话框。
- 关闭窗口后仍可被其他电脑访问；菜单栏图标恢复窗口；退出后端口和菜单栏图标释放。
- 重复启动不创建第二个服务；主机退出后客户端重新寻找主机；旧文件仍在原主机。
- Apple Silicon / Intel 如分别提供版本，应分别验证应用启动、资源路径与可写目录。
- 检查发布包在其他 Mac 上的运行、签名与系统提示；本次 Windows 测试不能代替这些检查。
