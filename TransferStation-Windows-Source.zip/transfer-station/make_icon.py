from PIL import Image, ImageDraw
from pathlib import Path

image = Image.new('RGBA', (256, 256))
draw = ImageDraw.Draw(image)
draw.rounded_rectangle((8, 8, 248, 248), radius=52, fill='#07a954')
draw.line([(62, 91), (186, 91)], fill='white', width=18)
draw.line([(153, 58), (188, 91), (153, 124)], fill='white', width=18)
draw.line([(194, 166), (70, 166)], fill='white', width=18)
draw.line([(103, 133), (68, 166), (103, 199)], fill='white', width=18)
image.save(Path(__file__).with_name('app.ico'), sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
