# 互传站 · 后台常驻版源码

这是本次 Windows `互传站_后台常驻版.exe` 对应的源码，包含桌面窗口、系统托盘、局域网自动发现、自动加入主机和文件传输。
交付日期：2026-10-03。开发和构建环境：Windows 11 x64、Python 3.12.14。

## 文件说明

| 文件 | 用途 |
|---|---|
| `desktop.py` | 桌面入口：单实例、服务生命周期、窗口、托盘初始化及自检 |
| `tray.py` | Windows 托盘：关闭隐藏、恢复窗口、彻底退出 |
| `server.py` | FastAPI 文件、文字、WebSocket 和网络状态接口 |
| `network.py` | UDP 自动发现、选择主机、加入请求、失联重新搜索 |
| `static/` | 内嵌界面 HTML、CSS、JavaScript，无前端编译步骤 |
| `app.ico` / `make_icon.py` | 应用图标及生成脚本 |
| `test_network.py` | Windows 多实例组网与界面集成测试 |
| `requirements.txt` | 应用直接依赖，移植时从此清单开始 |
| `requirements-windows-lock.txt` | 本次 Windows 构建环境的完整版本快照 |
| `build_windows.ps1` | 在 Windows 从本目录重新生成单文件 EXE |
| `MAC_PORTING.md` | Mac 移植需要替换的部分及验收项目 |

## Windows 开发和构建

在源码目录打开终端，准备 Python 3.12：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-windows-lock.txt
.\.venv\Scripts\python.exe desktop.py
```

运行 `build_windows.ps1` 会复用或创建 `.venv`，安装锁定依赖，并将 EXE 输出到 `dist/`。
桌面窗口使用本机 Microsoft Edge WebView2 Runtime。

## 当前行为

- 先发现并加入已有主机；没有可用主机时，本机成为主机。
- 所有已加入的设备共享会话，可双向发送文字和文件。
- 关闭窗口隐藏到托盘，服务继续运行；托盘菜单“退出互传站”才会停止服务。
- 默认 HTTP 端口 8787，被占用时尝试 8788–8797。
- 文件和记录留在当前主机；自动接替不会复制或合并原主机的历史。
- 默认数据目录为 EXE 旁边的 `data/`；开发时在源码旁边。可用 `TRANSFER_DATA_DIR` 改为隔离目录。

## 测试

测试会启动独立实例并创建测试目录，请在可信网络下运行：

```powershell
.\.venv\Scripts\python.exe test_network.py --gui-client
.\.venv\Scripts\python.exe test_network.py --exe dist\互传站_后台常驻版.exe --gui-client
```

`desktop.py --self-test` 会通过实际窗口发送测试消息和文件，检查托盘隐藏／恢复／退出并写入 `self-test.json`。
必须为自检设置独立 `TRANSFER_DATA_DIR` 和独立 `TRANSFER_DISCOVERY_PORT`，避免加入实际会话。

已验证：Windows 最终 EXE 的窗口收发、托盘隐藏后收发、恢复窗口、重复启动恢复、退出后图标和服务清理。
上一自动组网版本已通过本机多实例发现、自动加入、手动 IP、主机接替和同时启动测试；本次托盘修改未更改网络模块。
没有进行第二台实体电脑或 Mac 的实机验证。

## Mac 移植

请先读 `MAC_PORTING.md`。这是完整的当前 Windows 源码，不是已经适配好的 Mac 应用；不能直接把 Windows EXE 改后缀使用。
源码包不包含聊天记录、上传文件、浏览器配置、虚拟环境或测试数据。
