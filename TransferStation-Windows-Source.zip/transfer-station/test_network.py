"""Real processes + UDP discovery + HTTP/WebSocket + optional packaged desktop UI."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import HTTPError
from network import endpoint

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / ('network-check-' + str(int(time.time())))
BASE.mkdir()
http = build_opener(ProxyHandler({}))
children = []
port_socket = socket.socket(type=socket.SOCK_DGRAM)
port_socket.bind(('127.0.0.1', 0))
discovery_port = port_socket.getsockname()[1]
port_socket.close()
EXE = Path(sys.argv[sys.argv.index('--exe') + 1]).resolve() if '--exe' in sys.argv else None


def request(url, payload=None, headers=None):
    data = json.dumps(payload).encode() if payload is not None else None
    with http.open(Request(url, data=data, headers={'Content-Type': 'application/json', **(headers or {})}), timeout=3) as r:
        return json.load(r)


def wait_for(fn, seconds=20):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        try:
            result = fn()
            if result:
                return result
        except (OSError, ValueError):
            pass
        time.sleep(.2)
    raise AssertionError('Timed out: ' + str(fn))


def start(name, gui=False, discovery=None):
    data = BASE / name
    data.mkdir(exist_ok=True)
    env = dict(os.environ, TRANSFER_DATA_DIR=str(data), TRANSFER_DISCOVERY_PORT=str(discovery or discovery_port))
    command = [str(EXE)] if EXE else [sys.executable, str(ROOT / 'desktop.py')]
    command += ['--self-test' if gui else '--headless-test']
    log = (data / 'process.log').open('w', encoding='utf-8')
    proc = subprocess.Popen(command, env=env, stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
    children.append(proc)
    if gui:
        return proc, data
    url = wait_for(lambda: (data / 'endpoint.txt').read_text() if (data / 'endpoint.txt').exists() else None)
    wait_for(lambda: request(url + '/api/network'))
    return proc, url, data


def view(node):
    return request(node[1] + '/api/network')


def stop(node):
    # PyInstaller onefile has a parent bootloader process and a child process.
    proc = node[0]
    subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proc.wait(timeout=10)


report = {}
try:
    for bad in ['https://192.168.1.1', '8.8.8.8:80', '127.0.0.1:8787/a', 'localhost', '192.168.1.1:99999', 'http://user@192.168.1.1']:
        try:
            endpoint(bad)
        except (ValueError, TypeError):
            pass
        else:
            raise AssertionError('Unsafe address accepted: ' + bad)
    report['address_validation'] = True
    a = start('host-a')
    wait_for(lambda: view(a)['role'] == 'host')
    b = start('client-b')
    wait_for(lambda: view(b)['role'] == 'client')
    assert view(b)['target_id'] == view(a)['node_id']
    wait_for(lambda: len(view(a)['members']) == 1)
    report['automatic_discovery_and_join'] = True
    print('PASS discovery, join request and host acknowledgement', flush=True)

    host_url = view(b)['target']
    from websockets.sync.client import connect
    with connect(host_url.replace('http:', 'ws:') + '/api/live', proxy=None) as ws:
        request(host_url + '/api/messages', dict(content='来自客户端 B', sender='B'))
        assert json.loads(ws.recv(timeout=3))['data']['content'] == '来自客户端 B'
        request(a[1] + '/api/messages', dict(content='来自主机 A', sender='A'))
        assert json.loads(ws.recv(timeout=3))['data']['content'] == '来自主机 A'
    assert len(request(host_url + '/api/feed')['messages']) == 2
    report['bidirectional_messages_and_live_events'] = True

    before = view(b)['target_id']
    try:
        request(b[1] + '/api/network/connect', {'address': '127.0.0.1:1'}, {'X-Transfer-Control': '1'})
    except HTTPError as error:
        assert error.code == 400
    assert view(b)['target_id'] == before
    try:
        request(b[1] + '/api/network/rescan', {})
    except HTTPError as error:
        assert error.code == 403
    else:
        raise AssertionError('Missing control header was accepted')
    report['failed_connect_keeps_session_and_controls_protected'] = True

    preflight = Request(host_url + '/api/messages', method='OPTIONS', headers={
        'Origin': b[1], 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type'})
    with http.open(preflight) as response:
        assert response.headers['Access-Control-Allow-Origin'] == b[1]
    report['desktop_cross_origin_access'] = True

    manual = start('manual-isolated', discovery=discovery_port + 1)
    wait_for(lambda: view(manual)['role'] == 'host')
    request(manual[1] + '/api/network/connect', {'address': host_url}, {'X-Transfer-Control': '1', 'Origin': manual[1]})
    assert view(manual)['target_id'] == view(a)['node_id']
    report['manual_connection_without_discovery'] = True
    try:
        request(manual[1] + '/api/messages', dict(content='must not create split room'))
    except HTTPError as error:
        assert error.code == 409
    else:
        raise AssertionError('Client accepted a message into its own inactive room')
    stop(manual)

    if '--gui-client' in sys.argv:
        gui, data = start('gui-client', gui=True)
        gui.wait(timeout=65)
        result = json.loads((data / 'self-test.json').read_text(encoding='utf-8'))
        assert result.get('passed'), result
        assert result['role'] == 'client', result
        report['packaged_gui_client'] = result
        report['screenshot'] = str(data / 'window.png')
        print('PASS real desktop joins host and uploads/downloads from window', flush=True)

    stop(a)
    wait_for(lambda: view(b)['role'] == 'host', seconds=30)
    report['host_offline_client_becomes_host'] = True
    assert request(b[1] + '/api/feed')['messages'] == []
    assert json.loads((a[2] / 'state.json').read_text(encoding='utf-8'))['messages']
    report['original_history_preserved_on_original_host'] = True
    a2 = start('host-a')
    wait_for(lambda: view(a2)['role'] == 'client')
    assert view(a2)['target_id'] == view(b)['node_id']
    report['returning_host_joins_current_host'] = True
    print('PASS failover, history preservation and returning host', flush=True)
    stop(a2)
    stop(b)

    c = start('simultaneous-c')
    d = start('simultaneous-d')
    wait_for(lambda: sorted([view(c)['role'], view(d)['role']]) == ['client', 'host'])
    host, client = (c, d) if view(c)['role'] == 'host' else (d, c)
    assert view(client)['target_id'] == view(host)['node_id']
    report['simultaneous_start_one_host'] = True
    report['passed'] = True
    print('PASS simultaneous startup selects one host', flush=True)
finally:
    for proc in children:
        if proc.poll() is None:
            stop((proc,))
    (BASE / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(BASE, flush=True)
