"""Small, LAN-only peer discovery and shared-session selection."""
import ipaddress
import json
import re
import socket
import threading
import time
import uuid
from urllib.parse import urlsplit
from urllib.request import build_opener, ProxyHandler, HTTPRedirectHandler, Request

PROTOCOL = 'transfer-station/2'
GROUP = '239.255.87.87'
LAN_RANGES = tuple(map(ipaddress.ip_network, ('10.0.0.0/8', '172.16.0.0/12',
    '192.168.0.0/16', '169.254.0.0/16', '127.0.0.0/8')))


def lan_address(value):
    address = ipaddress.ip_address(value)
    if address.version != 4 or not any(address in net for net in LAN_RANGES):
        raise ValueError('请输入内网 IPv4 地址，例如 192.168.1.20:8787')
    return str(address)


def endpoint(value):
    parts = urlsplit(value.strip() if '://' in value else 'http://' + value.strip())
    if parts.scheme != 'http' or parts.username or parts.password or parts.path not in ('', '/') or parts.query or parts.fragment:
        raise ValueError('请输入 IP:端口，不要填写其他网址或路径')
    return f'http://{lan_address(parts.hostname)}:{parts.port or 8787}'


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def request_json(url, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    request = Request(url, data=data, headers={'Content-Type': 'application/json'})
    with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=1.2) as response:
        raw = response.read(65537)
        if len(raw) > 65536:
            raise ValueError('对方返回的数据过大')
        return json.loads(raw)


class Network:
    def __init__(self, port, data, primary_ip, discovery_port=48787):
        self.port, self.discovery_port = port, discovery_port
        identity = data / 'device-id.txt'
        self.id = identity.read_text().strip() if identity.exists() else uuid.uuid4().hex
        if not re.fullmatch('[a-f0-9]{32}', self.id):
            self.id = uuid.uuid4().hex
        identity.write_text(self.id)
        self.name = socket.gethostname()[:60]
        self.addresses = [primary_ip]
        try:
            self.addresses += socket.gethostbyname_ex(socket.gethostname())[2]
        except OSError:
            pass
        self.addresses = list(dict.fromkeys(ip for ip in self.addresses
            if any(ipaddress.ip_address(ip) in n for n in LAN_RANGES) and not ip.startswith('127.')))
        if not self.addresses:
            self.addresses = ['127.0.0.1']
        self.url = f'http://{self.addresses[0]}:{port}'
        self.role, self.target, self.target_id = 'searching', '', ''
        self.note = '正在寻找局域网主机，约需 4 秒…'
        self.warning = ''
        self.peers, self.members = {}, {}
        self.lock = threading.RLock()
        self.join_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.scan_at = time.monotonic()
        self.generation = 0
        self.sock = None
        self.threads = []

    def start(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self.sock.bind(('', self.discovery_port))
            self.sock.settimeout(.4)
            self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
            self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
            for ip in self.addresses:
                try:
                    self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                        socket.inet_aton(GROUP) + socket.inet_aton(ip))
                except OSError:
                    pass
            receiver = threading.Thread(target=self.receive, daemon=True)
            self.threads.append(receiver)
            receiver.start()
        except OSError:
            if self.sock:
                self.sock.close()
            self.sock = None
            self.warning = '自动发现不可用，可手动输入主机 IP 连接。'
        worker = threading.Thread(target=self.run, daemon=True)
        self.threads.append(worker)
        worker.start()

    def stop(self):
        self.stop_event.set()
        if self.sock:
            self.sock.close()
        for worker in self.threads:
            worker.join(timeout=2)

    def announce(self):
        if not self.sock:
            return
        with self.lock:
            payload = json.dumps(dict(protocol=PROTOCOL, id=self.id, name=self.name,
                port=self.port, role=self.role, target_id=self.target_id)).encode()
        for ip in self.addresses:
            try:
                self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(ip))
                self.sock.sendto(payload, (GROUP, self.discovery_port))
            except OSError:
                pass
        try:
            self.sock.sendto(payload, ('255.255.255.255', self.discovery_port))
        except OSError:
            pass

    def receive(self):
        while not self.stop_event.is_set():
            try:
                raw, sender = self.sock.recvfrom(2049)
                if len(raw) > 2048:
                    continue
                item = json.loads(raw)
                if not isinstance(item, dict) or item.get('protocol') != PROTOCOL or item.get('id') == self.id:
                    continue
                if not re.fullmatch('[a-f0-9]{32}', str(item.get('id', ''))):
                    continue
                if item.get('role') not in ('searching', 'host', 'client') or type(item.get('port')) is not int or not 1 <= item['port'] <= 65535:
                    continue
                ip = lan_address(sender[0])
                peer = dict(id=item['id'], name=str(item.get('name', '设备'))[:60],
                    url=f'http://{ip}:{item["port"]}', role=item['role'],
                    target_id=str(item.get('target_id', ''))[:32], seen=time.monotonic())
                with self.lock:
                    if len(self.peers) < 64 or peer['id'] in self.peers:
                        self.peers[peer['id']] = peer
            except (OSError, ValueError, TypeError):
                continue

    def probe(self, url):
        status = request_json(endpoint(url) + '/api/status')
        if not isinstance(status, dict) or status.get('protocol') != PROTOCOL or status.get('role') != 'host':
            raise ValueError('对方不是可加入的新版主机，请选择标记为“主机”的设备')
        if not re.fullmatch('[a-f0-9]{32}', str(status.get('node_id', ''))):
            raise ValueError('主机身份无效')
        return status

    def join(self, value, expected_generation=None):
        url = endpoint(value)
        with self.join_lock:
            with self.lock:
                generation = self.generation if expected_generation is None else expected_generation
            status = self.probe(url)
            if status['node_id'] == self.id:
                raise ValueError('这是本机地址，请连接另一台主机')
            request_json(url + '/api/network/join', dict(id=self.id, name=self.name, port=self.port))
            with self.lock:
                if generation != self.generation:
                    return
                self.role, self.target, self.target_id = 'client', url, status['node_id']
                self.note = f'已加入 {status["host"]}。双方可互传，内容保存在该主机。'
                self.generation += 1
            self.announce()

    def rescan(self, reason='正在重新寻找主机…'):
        with self.lock:
            self.role, self.target, self.target_id = 'searching', '', ''
            self.note = reason
            self.scan_at = time.monotonic()
            self.generation += 1
        self.announce()

    def become_host(self, generation):
        with self.lock:
            if generation != self.generation:
                return
            self.role, self.target, self.target_id = 'host', '', self.id
            self.note = '未发现可加入的主机，本机已成为主机，等待其他设备加入。'
            self.generation += 1
        self.announce()

    def accept(self, item, ip):
        if not isinstance(item, dict) or not re.fullmatch('[a-f0-9]{32}', str(item.get('id', ''))):
            raise ValueError('设备身份无效')
        lan_address(ip)
        name = str(item.get('name', '设备'))[:60]
        with self.lock:
            if self.role != 'host':
                raise ValueError('本机当前不是主机，请重新搜索')
            if item['id'] not in self.members or time.monotonic() - self.members[item['id']]['seen'] > 10:
                self.note = f'{name} 请求加入，已自动接入。现在可双向发送文字和文件。'
            if len(self.members) >= 64 and item['id'] not in self.members:
                raise ValueError('连接设备过多')
            self.members[item['id']] = dict(id=item['id'], name=name, ip=ip, seen=time.monotonic())

    def snapshot(self):
        with self.lock:
            now = time.monotonic()
            peers = [dict(p) for p in self.peers.values() if now - p['seen'] < 7]
            members = [dict(p) for p in self.members.values() if now - p['seen'] < 10]
            return dict(role=self.role, node_id=self.id, name=self.name, target=self.target,
                target_id=self.target_id, url=self.target or self.url, addresses=self.addresses,
                port=self.port, peers=sorted(peers, key=lambda p: (p['role'] != 'host', p['name'])),
                members=members, note=self.note, warning=self.warning)

    def run(self):
        failures, tick = 0, 0
        while not self.stop_event.is_set():
            self.announce()
            with self.lock:
                generation, role, target = self.generation, self.role, self.target
                elapsed = time.monotonic() - self.scan_at
            view = self.snapshot()
            if role == 'searching' and elapsed >= 3.5:
                hosts = sorted((p for p in view['peers'] if p['role'] == 'host'), key=lambda p: p['id'])
                joined = False
                for peer in hosts[:8]:
                    try:
                        self.join(peer['url'], generation)
                        joined = True
                        break
                    except (OSError, ValueError, KeyError):
                        pass
                candidates = [self.id] + [p['id'] for p in view['peers'] if p['role'] == 'searching']
                if not joined and (min(candidates) == self.id or elapsed >= 8):
                    self.become_host(generation)
                failures = 0
            elif role == 'client' and tick % 3 == 0:
                try:
                    status = self.probe(target)
                    if status['node_id'] != view['target_id']:
                        raise ValueError('主机已变更')
                    request_json(target + '/api/network/join', dict(id=self.id, name=self.name, port=self.port))
                    failures = 0
                except (OSError, ValueError, KeyError):
                    failures += 1
                    if failures >= 3:
                        with self.lock:
                            if self.generation == generation:
                                self.rescan('原主机已离线，正在寻找新主机。原文件仍保存在原主机。')
                        failures = 0
            with self.lock:
                cutoff = time.monotonic() - 30
                self.peers = {k: v for k, v in self.peers.items() if v['seen'] > cutoff}
                self.members = {k: v for k, v in self.members.items() if v['seen'] > cutoff}
            tick += 1
            self.stop_event.wait(.8)
