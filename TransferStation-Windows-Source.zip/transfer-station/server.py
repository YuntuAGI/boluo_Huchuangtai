from __future__ import annotations

import json
import mimetypes
import os
import re
import socket
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, Query, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from network import PROTOCOL


SOURCE_ROOT = Path(__file__).resolve().parent
APP_ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else SOURCE_ROOT
BUNDLE_ROOT = Path(getattr(sys, "_MEIPASS", SOURCE_ROOT))
STATIC_ROOT = BUNDLE_ROOT / "static"
DATA_ROOT = Path(os.environ.get("TRANSFER_DATA_DIR", str(APP_ROOT / "data")))
FILE_ROOT = DATA_ROOT / "files"
STATE_PATH = DATA_ROOT / "state.json"
FILE_ROOT.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="互传站", docs_url=None, redoc_url=None)
app.add_middleware(CORSMiddleware,
    allow_origin_regex=r'http://(?:localhost|127\.0\.0\.1|192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|169\.254\.\d{1,3}\.\d{1,3})(?::\d+)?',
    allow_methods=['GET', 'POST', 'DELETE'], allow_headers=['Content-Type'])
network = None


@app.middleware('http')
async def active_host_only(request, call_next):
    path = request.url.path
    if network and network.role != 'host' and request.method != 'OPTIONS' and (
            path in ('/api/feed', '/api/messages', '/api/conversation', '/api/files') or path.startswith('/api/files/')):
        return JSONResponse({'detail': '本机当前不是主机，请等待客户端连接到当前主机。'}, status_code=409)
    return await call_next(request)
state_lock = threading.Lock()
state: dict[str, list[dict[str, Any]]] = {"files": [], "messages": []}


def load_state() -> None:
    if not STATE_PATH.exists():
        return
    try:
        loaded = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        state["files"] = [item for item in loaded.get("files", []) if (FILE_ROOT / item.get("stored_name", "")).is_file()]
        state["messages"] = loaded.get("messages", [])[-300:]
    except (OSError, ValueError, TypeError):
        # A damaged history must not prevent the transfer service from starting.
        pass


def save_state() -> None:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(STATE_PATH)


def public_file(item: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in item.items() if key != "stored_name"}


def local_ip() -> str:
    candidates: list[str] = []
    try:
        output = subprocess.run(
            ["ipconfig"], capture_output=True, text=True, errors="ignore", timeout=3, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        ).stdout
        candidates.extend(re.findall(r"IPv4[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", output, flags=re.IGNORECASE))
    except (OSError, subprocess.SubprocessError):
        pass

    connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        connection.connect(("8.8.8.8", 80))
        candidates.append(connection.getsockname()[0])
    except OSError:
        try:
            candidates.append(socket.gethostbyname(socket.gethostname()))
        except OSError:
            pass
    finally:
        connection.close()

    # Home/office LAN addresses are preferred over VPN and virtual adapters.
    priorities = (
        lambda address: address.startswith("192.168."),
        lambda address: address.startswith("10."),
        lambda address: address.startswith(tuple(f"172.{part}." for part in range(16, 32))),
    )
    for matches in priorities:
        if match := next((address for address in candidates if matches(address)), None):
            return match
    return next((address for address in candidates if not address.startswith(("127.", "169.254."))), "127.0.0.1")


class ConnectionManager:
    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.connections.add(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        self.connections.discard(websocket)

    async def broadcast(self, payload: dict[str, Any]) -> None:
        stale: list[WebSocket] = []
        for connection in list(self.connections):
            try:
                await connection.send_json(payload)
            except Exception:
                stale.append(connection)
        for connection in stale:
            self.disconnect(connection)


manager = ConnectionManager()
load_state()


@app.get("/api/status")
def status() -> dict[str, Any]:
    return {"ok": True, "host": socket.gethostname(),
        "address": network.addresses[0] if network else local_ip(), "time": int(time.time()),
        "protocol": PROTOCOL, "node_id": network.id if network else '',
        "role": network.role if network else 'host'}


@app.get("/api/feed")
def feed() -> dict[str, Any]:
    with state_lock:
        return {
            "files": [public_file(item) for item in reversed(state["files"][-100:])],
            "messages": state["messages"][-300:],
        }


@app.post("/api/files")
async def upload_file(
    file: UploadFile = File(...),
    sender: str = Form(default="访客"),
) -> dict[str, Any]:
    original_name = Path(file.filename or "未命名文件").name[:240]
    if not original_name:
        raise HTTPException(status_code=400, detail="文件名无效")

    file_id = uuid.uuid4().hex[:16]
    suffix = Path(original_name).suffix[:20]
    stored_name = f"{file_id}{suffix}"
    destination = FILE_ROOT / stored_name
    size = 0
    try:
        with destination.open("wb") as output:
            while chunk := await file.read(4 * 1024 * 1024):
                size += len(chunk)
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await file.close()

    item = {
        "id": file_id,
        "name": original_name,
        "stored_name": stored_name,
        "size": size,
        "type": file.content_type or mimetypes.guess_type(original_name)[0] or "application/octet-stream",
        "sender": sender.strip()[:40] or "访客",
        "created_at": int(time.time() * 1000),
        "download_url": f"/api/files/{file_id}",
    }
    with state_lock:
        state["files"].append(item)
        save_state()
    result = public_file(item)
    await manager.broadcast({"type": "file", "data": result})
    return result


@app.get("/api/files/{file_id}")
def download_file(file_id: str, inline: bool = Query(default=False)) -> FileResponse:
    with state_lock:
        item = next((entry for entry in state["files"] if entry["id"] == file_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="文件不存在")
    path = FILE_ROOT / item["stored_name"]
    if not path.is_file():
        raise HTTPException(status_code=404, detail="文件已被移除")
    disposition = "inline" if inline and str(item["type"]).startswith("image/") else "attachment"
    return FileResponse(
        path,
        media_type=item["type"],
        filename=item["name"],
        content_disposition_type=disposition,
    )


@app.post("/api/messages")
async def create_message(request: Request) -> dict[str, Any]:
    payload = await request.json()
    content = str(payload.get("content", "")).strip()
    if not content:
        raise HTTPException(status_code=400, detail="请输入文字")
    if len(content) > 10000:
        raise HTTPException(status_code=400, detail="单条文字不能超过 10000 字")
    item = {
        "id": uuid.uuid4().hex[:16],
        "content": content,
        "sender": str(payload.get("sender", "访客")).strip()[:40] or "访客",
        "created_at": int(time.time() * 1000),
    }
    with state_lock:
        state["messages"].append(item)
        state["messages"] = state["messages"][-300:]
        save_state()
    await manager.broadcast({"type": "message", "data": item})
    return item


@app.delete("/api/conversation")
async def clear_conversation() -> dict[str, bool]:
    with state_lock:
        state["files"] = []
        state["messages"] = []
        save_state()
    await manager.broadcast({"type": "clear"})
    return {"ok": True}


@app.websocket("/api/live")
async def live(websocket: WebSocket) -> None:
    if network and network.role != 'host':
        await websocket.close(code=1013)
        return
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception:
        manager.disconnect(websocket)


@app.get('/api/network')
def network_status(request: Request):
    if not network:
        raise HTTPException(503, '设备发现尚未启动')
    result = network.snapshot()
    result['can_control'] = request.client.host in ('127.0.0.1', '::1')
    return result


def require_local_control(request):
    if request.client.host not in ('127.0.0.1', '::1') or request.headers.get('x-transfer-control') != '1':
        raise HTTPException(403, '请在本机客户端操作连接')
    origin = request.headers.get('origin')
    if origin and origin != str(request.base_url).rstrip('/'):
        raise HTTPException(403, '连接操作必须来自本机窗口')


@app.post('/api/network/connect')
def network_connect(request: Request, payload: dict):
    require_local_control(request)
    try:
        network.join(str(payload.get('address', '')))
        return network.snapshot()
    except (OSError, ValueError, TypeError, KeyError):
        raise HTTPException(400, '连接失败：请核对内网 IP 和端口，确认对方打开新版主机并允许专用网络访问。')


@app.post('/api/network/rescan')
def network_rescan(request: Request):
    require_local_control(request)
    network.rescan()
    return network.snapshot()


@app.post('/api/network/join')
def network_join(request: Request, payload: dict):
    try:
        network.accept(payload, request.client.host)
        return {'ok': True, 'message': '已接入，可双向传输'}
    except (ValueError, TypeError):
        raise HTTPException(409, '主机当前无法接入，请重新搜索')


app.mount("/", StaticFiles(directory=STATIC_ROOT, html=True), name="static")


if __name__ == "__main__":
    import uvicorn

    if "--print-address" in sys.argv:
        print(local_ip())
        raise SystemExit(0)
    print(f"局域网地址：http://{local_ip()}:8787")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open("http://127.0.0.1:8787")).start()
    uvicorn.run(app, host="0.0.0.0", port=8787, log_level="info")
