#!/usr/bin/env python3
"""Regenerate the dependency-free Xcode project using Python's standard library."""
from pathlib import Path
import hashlib
import plistlib
ROOT = Path(__file__).resolve().parent
objects = {}
def ident(name): return hashlib.sha1(name.encode()).hexdigest()[:24].upper()
def add(key, **fields): objects[ident(key)] = fields; return ident(key)
app_files = sorted((ROOT / 'TransferStation').glob('*.swift'))
source_refs = [add(p.name, isa='PBXFileReference', lastKnownFileType='sourcecode.swift', path=p.name, sourceTree='<group>') for p in app_files]
source_builds = [add(p.name+'build', isa='PBXBuildFile', fileRef=ident(p.name)) for p in app_files]
test_ref = add('UITests.swift', isa='PBXFileReference', lastKnownFileType='sourcecode.swift', path='UITests.swift', sourceTree='<group>')
test_build = add('testbuild', isa='PBXBuildFile', fileRef=test_ref)
app_product = add('app-product', isa='PBXFileReference', explicitFileType='wrapper.application', path='TransferStation.app', sourceTree='BUILT_PRODUCTS_DIR')
test_product = add('test-product', isa='PBXFileReference', explicitFileType='wrapper.cfbundle', path='TransferStationUITests.xctest', sourceTree='BUILT_PRODUCTS_DIR')
app_group = add('app-group', isa='PBXGroup', path='TransferStation', sourceTree='<group>', children=source_refs)
test_group = add('test-group', isa='PBXGroup', path='Tests', sourceTree='<group>', children=[test_ref])
products = add('products', isa='PBXGroup', name='Products', sourceTree='<group>', children=[app_product,test_product])
main = add('main', isa='PBXGroup', sourceTree='<group>', children=[app_group,test_group,products])
def phase(name, kind, files=[]): return add(name, isa=kind, buildActionMask=2147483647, files=files, runOnlyForDeploymentPostprocessing=0)
def configs(name, extra):
    refs=[]
    for mode in ['Debug','Release']:
        settings=dict(SWIFT_VERSION='5.0', IPHONEOS_DEPLOYMENT_TARGET='17.0', SDKROOT='iphoneos', TARGETED_DEVICE_FAMILY='1,2', CLANG_ENABLE_MODULES='YES', SWIFT_OPTIMIZATION_LEVEL='-Onone' if mode=='Debug' else '-O', **extra)
        if mode=='Debug': settings.update(SWIFT_ACTIVE_COMPILATION_CONDITIONS='DEBUG', ENABLE_TESTABILITY='YES')
        refs.append(add(name+mode, isa='XCBuildConfiguration', buildSettings=settings, name=mode))
    return add(name+'configlist', isa='XCConfigurationList', buildConfigurations=refs, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')
app_config=configs('app', dict(PRODUCT_NAME='TransferStation', PRODUCT_BUNDLE_IDENTIFIER='com.transferstation.iphone', INFOPLIST_FILE='TransferStation/Info.plist', GENERATE_INFOPLIST_FILE='NO', CODE_SIGN_STYLE='Automatic', CURRENT_PROJECT_VERSION='1', MARKETING_VERSION='1.1.0', ASSETCATALOG_COMPILER_APPICON_NAME='AppIcon'))
asset_ref=add('assets',isa='PBXFileReference',lastKnownFileType='folder.assetcatalog',path='Assets.xcassets',sourceTree='<group>')
objects[app_group]['children'].append(asset_ref)
asset_build=add('asset-build',isa='PBXBuildFile',fileRef=asset_ref)
privacy_ref=add('privacy',isa='PBXFileReference',lastKnownFileType='text.xml',path='PrivacyInfo.xcprivacy',sourceTree='<group>')
objects[app_group]['children'].append(privacy_ref)
privacy_build=add('privacy-build',isa='PBXBuildFile',fileRef=privacy_ref)
app=add('app', isa='PBXNativeTarget', buildConfigurationList=app_config, buildPhases=[phase('sources','PBXSourcesBuildPhase',source_builds),phase('frameworks','PBXFrameworksBuildPhase'),phase('resources','PBXResourcesBuildPhase',[asset_build,privacy_build])], buildRules=[], dependencies=[], name='TransferStation', productName='TransferStation', productReference=app_product, productType='com.apple.product-type.application')
proxy=add('proxy',isa='PBXContainerItemProxy',containerPortal=ident('project'),proxyType=1,remoteGlobalIDString=app,remoteInfo='TransferStation')
dep=add('dep',isa='PBXTargetDependency',target=app,targetProxy=proxy)
test=add('tests',isa='PBXNativeTarget',buildConfigurationList=configs('test',dict(PRODUCT_NAME='TransferStationUITests', PRODUCT_BUNDLE_IDENTIFIER='com.transferstation.iphone.uitests',GENERATE_INFOPLIST_FILE='YES',TEST_TARGET_NAME='TransferStation',CODE_SIGN_STYLE='Automatic')),buildPhases=[phase('test-sources','PBXSourcesBuildPhase',[test_build]),phase('test-frameworks','PBXFrameworksBuildPhase'),phase('test-resources','PBXResourcesBuildPhase')],buildRules=[],dependencies=[dep],name='TransferStationUITests',productName='TransferStationUITests',productReference=test_product,productType='com.apple.product-type.bundle.ui-testing')
project=add('project',isa='PBXProject',attributes={'LastUpgradeCheck':'1600','TargetAttributes':{app:{'CreatedOnToolsVersion':'16.0'},test:{'CreatedOnToolsVersion':'16.0','TestTargetID':app}}},buildConfigurationList=configs('project',{}),compatibilityVersion='Xcode 14.0',developmentRegion='zh-Hans',knownRegions=['zh-Hans','en','Base'],mainGroup=main,productRefGroup=products,projectDirPath='',projectRoot='',targets=[app,test])
proj=ROOT/'TransferStation.xcodeproj';proj.mkdir(exist_ok=True)
(proj/'project.pbxproj').write_bytes(plistlib.dumps(dict(archiveVersion='1',classes={},objectVersion='56',objects=objects,rootObject=project)))
scheme=f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app}" BuildableName="TransferStation.app" BlueprintName="TransferStation" ReferencedContainer="container:TransferStation.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" shouldUseLaunchSchemeArgsEnv="YES"><EnvironmentVariables><EnvironmentVariable key="TRANSFER_TEST_ADDRESS" value="$(TRANSFER_TEST_ADDRESS)" isEnabled="YES"/></EnvironmentVariables><Testables><TestableReference skipped="NO"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{test}" BuildableName="TransferStationUITests.xctest" BlueprintName="TransferStationUITests" ReferencedContainer="container:TransferStation.xcodeproj"/></TestableReference></Testables></TestAction>
<LaunchAction buildConfiguration="Debug" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app}" BuildableName="TransferStation.app" BlueprintName="TransferStation" ReferencedContainer="container:TransferStation.xcodeproj"/></BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>'''
p=proj/'xcshareddata/xcschemes';p.mkdir(parents=True,exist_ok=True);(p/'TransferStation.xcscheme').write_text(scheme)
