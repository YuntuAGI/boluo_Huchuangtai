# 互传站 iPhone 版

iOS 17 及以上的原生 SwiftUI 客户端。与本项目 Mac 版、Windows 后台常驻版使用同一个 `transfer-station/2` 会话，支持双向文字、照片和文件传输，无第三方依赖。

## 使用

1. iPhone 和电脑连接同一 Wi-Fi；电脑打开互传站，并等待自动选出主机。
2. 从电脑窗口找到内网 IPv4 地址，例如 `192.168.1.20:8787`。填写实际显示的端口。
3. 打开 iPhone 互传站，输入电脑地址和发送者名称，点击「连接电脑」。首次连接时允许本地网络访问。
4. 底部发送文字，从「文件」或「照片」选择内容。电脑和 iPhone 发出的内容都会进入同一列表；可筛选文字、文件。
5. 点击文件右侧接收按钮，下载后打开系统分享面板，可以保存到其他位置或交给其他 App。已下载文件也保存在「文件 → 我的 iPhone → 互传站 → 收到的文件」。
6. 复制文字可长按或选择文字；再次传输文件可从系统文件选择器选取。照片选择器仅向本应用提供你选中的照片。

输入的电脑若当前也是客户端，iPhone 会查询它的当前主机并连接。主机退出或 Wi-Fi 改变后，请在右上角选择「重新连接」；必要时断开并填写新的电脑地址。回到前台会尝试重新连接原地址。

## 安装到 iPhone

仓库提供完整 Xcode 工程和源码包，不是 App Store / TestFlight 发行版。

1. 在 Mac 上用 Xcode 15 或更新版本打开 `TransferStation.xcodeproj`（本次验证使用 Xcode 27.0）。
2. 选择 `TransferStation` target，在 Signing & Capabilities 中选择自己的 Apple 开发团队。若 Bundle Identifier 被占用，改成自己唯一的标识。
3. 连接 iPhone，选择该设备，点击 Run。按手机提示启用开发者模式、信任自己的开发者账号。
4. 开发签名有有效期，以 Xcode 生成的描述文件为准；过期后重新构建安装。面向其他人的通用安装包需要正式分发签名或 TestFlight。

命令行模拟器构建（无需 Apple 开发账号）：

```sh
xcodebuild -project TransferStation.xcodeproj -scheme TransferStation \
  -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath /tmp/transferstation-ios CODE_SIGNING_ALLOWED=NO build
```

命令行真机构建：

```sh
xcodebuild -project TransferStation.xcodeproj -scheme TransferStation \
  -destination 'generic/platform=iOS' -configuration Release \
  -derivedDataPath /tmp/transferstation-ios-device \
  DEVELOPMENT_TEAM=你的团队ID -allowProvisioningUpdates build
```

使用 `/tmp` 构建可避免 iCloud 同步目录附加 Finder 元数据而导致签名失败。工程已纳入仓库，无需安装工程生成工具；`python3 generate_project.py` 仅用于重新生成工程文件。

## 范围和限制

- iPhone 是电脑会话的客户端，不参与主机选举，不需要 UDP 广播/组播权限。电脑须保持开启。
- 仅支持手动输入局域网 IPv4；不扫描全网、不使用云端中转。默认端口 8787，可指定其他端口。
- 前台每 2 秒更新记录。iOS 后台不保证传输，离开 App 时停止连接；回到前台重新连接，不自动重发未确认的操作。中断后先检查会话记录再重试，避免重复。
- 单文件上限 1 GB，上传通过磁盘缓存分块处理；上传期间需要至少容纳一份文件的额外磁盘空间。照片选择可能再产生一份临时副本。
- 电脑沿用现有无配对密码的共享会话，局域网内其他成员也能访问；传输是 HTTP，内容未端到端加密，只应在信任的局域网使用。
- 不提供跨 App 悬浮窗、持续后台接收、iPhone 独立主机或系统分享扩展；可在 App 内选择文件，接收后调用系统分享面板。
- 本机照片和文件不会自动上传。只有你选择并确认的文件会进入当前电脑会话。

## 验证

详见 [验证记录](VALIDATION.md)。测试在隔离数据目录运行，不能指向真实会话目录。

共享的 Foundation 客户端可直接在 Mac 上做协议测试：

```sh
xcrun swiftc -parse-as-library TransferStation/TransferClient.swift \
  Tests/ProtocolTests.swift -o /tmp/transfer-protocol-tests
/tmp/transfer-protocol-tests
```

端到端测试需要 Python 环境已安装电脑服务的 FastAPI、uvicorn、python-multipart 依赖。下面从完整仓库的 `ios` 目录启动本仓库 Mac 服务副本（单独的 iPhone 源码包不包含电脑服务，需把 `..` 换成另行下载的电脑版源码目录）：

```sh
python3 Tests/run_fixture.py .. --port 18887
# 另开终端
/tmp/transfer-protocol-tests 127.0.0.1:18887
```

UI 测试也使用 `127.0.0.1:18887` 的隔离服务。先启动一个模拟器并导入测试图片，再运行测试：

```sh
xcrun simctl addmedia booted TransferStation/Assets.xcassets/AppIcon.appiconset/AppIcon.png
xcodebuild -project TransferStation.xcodeproj -scheme TransferStation \
  -destination 'platform=iOS Simulator,name=你的模拟器名称' \
  -parallel-testing-enabled NO -derivedDataPath /tmp/transferstation-ios \
  CODE_SIGNING_ALLOWED=NO test
```

照片选择器 UI 测试使用 iOS 27 模拟器的可访问性标识，其他 iOS 版本可能需更新测试选择器；应用本身最低支持 iOS 17。

## 界面

以下是运行中的模拟器截图，内容均为测试数据。

<img src="screenshots/iphone-connect.png" width="300" alt="iPhone 连接电脑界面" />
<img src="screenshots/iphone-conversation.png" width="300" alt="iPhone 互传会话" />

<img src="screenshots/iphone-photo-dark.png" width="300" alt="深色模式照片发送成功" />

开发参考：[Apple 本地网络隐私](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)、[本地网络 ATS 配置](https://developer.apple.com/documentation/bundleresources/information-property-list/nsapptransportsecurity/nsallowslocalnetworking)、[UserDefaults 隐私声明](https://developer.apple.com/documentation/bundleresources/app-privacy-configuration/nsprivacyaccessedapitypes/nsprivacyaccessedapitype)。
