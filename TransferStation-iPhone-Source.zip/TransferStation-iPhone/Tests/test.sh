#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
binary=$(mktemp /tmp/transfer-protocol.XXXXXX)
trap 'rm -f "$binary"' EXIT
xcrun swiftc -parse-as-library TransferStation/TransferClient.swift Tests/ProtocolTests.swift -o "$binary"
"$binary" "$@"
