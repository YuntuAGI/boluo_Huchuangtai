import XCTest

final class UITests: XCTestCase {
    private var testAddress: String {
        let value = ProcessInfo.processInfo.environment["TRANSFER_TEST_ADDRESS"] ?? ""
        return value.isEmpty || value.contains("$(") ? "127.0.0.1:18887" : value
    }
    override func setUp() {
        continueAfterFailure = false
        addUIInterruptionMonitor(withDescription: "Local network permission") { alert in
            let text = alert.staticTexts.allElementsBoundByIndex.map(\.label).joined()
            guard text.contains("本地网络") || text.lowercased().contains("local network") else { return false }
            let allow = alert.buttons["允许"].exists ? alert.buttons["允许"] : alert.buttons["Allow"]
            guard allow.exists else { return false }
            allow.tap(); return true
        }
    }
    func testInvalidAddress() {
        let app = XCUIApplication()
        app.launchArguments = ["-stationAddress", "8.8.8.8", "-AppleInterfaceStyle", "Dark", "-UIPreferredContentSizeCategoryName", "UICTContentSizeCategoryXXXL"]
        app.launch()
        app.buttons["connectButton"].tap()
        XCTAssertTrue(app.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", "请输入电脑上的内网")).firstMatch.waitForExistence(timeout: 10))
        let shot = XCTAttachment(screenshot: app.screenshot()); shot.name = "iPhone-大字错误"; shot.lifetime = .keepAlways; add(shot)
    }
    func testPhotoPicker() {
        let app = XCUIApplication()
        app.launchArguments = ["-stationAddress", testAddress]
        app.launch()
        app.buttons["connectButton"].tap()
        app.tap()
        XCTAssertTrue(app.staticTexts["connectionStatus"].waitForExistence(timeout: 20))
        app.buttons["照片"].tap()
        let loading = app.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", "Loading")).firstMatch
        if loading.waitForExistence(timeout: 3) {
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: loading)
            waitForExpectations(timeout: 40)
        }
        let image = app.images.matching(identifier: "PXGGridLayout-Info").firstMatch
        XCTAssertTrue(image.waitForExistence(timeout: 20))
        image.tap()
        XCTAssertTrue(app.staticTexts["文件已发送"].waitForExistence(timeout: 30))
        let shot = XCTAttachment(screenshot: app.screenshot()); shot.name = "iPhone-照片发送"; shot.lifetime = .keepAlways; add(shot)
    }
    func testConnectSendReceive() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-stationAddress", testAddress, "-senderName", "iPhone 测试"]
        app.launch()
        XCTAssertTrue(app.buttons["connectButton"].waitForExistence(timeout: 10))
        let intro = XCTAttachment(screenshot: app.screenshot()); intro.name = "iPhone-连接"; intro.lifetime = .keepAlways; add(intro)
        app.buttons["connectButton"].tap()
        app.tap()
        XCTAssertTrue(app.staticTexts["connectionStatus"].waitForExistence(timeout: 20))
        let field = app.textFields["messageInput"]
        let editor = app.textViews["messageInput"]
        let input = field.exists ? field : editor
        XCTAssertTrue(input.waitForExistence(timeout: 5)); input.tap(); input.typeText("Hello from iPhone UI")
        app.buttons["sendButton"].tap()
        XCTAssertTrue(app.staticTexts["Hello from iPhone UI"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["电脑发来的测试文字"].exists)
        app.buttons["接收 电脑文件.txt"].tap()
        XCTAssertTrue(app.staticTexts["已保存到本机，可在“文件”中查看"].waitForExistence(timeout: 10))
        let sheet = XCTAttachment(screenshot: app.screenshot()); sheet.name = "iPhone-接收分享"; sheet.lifetime = .keepAlways; add(sheet)
        app.swipeDown()
        let chat = XCTAttachment(screenshot: app.screenshot()); chat.name = "iPhone-会话"; chat.lifetime = .keepAlways; add(chat)
    }
}
