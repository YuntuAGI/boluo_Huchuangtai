#!/usr/bin/env python3
"""Run an isolated copy of a desktop server for iPhone integration tests."""
import argparse
import os
from pathlib import Path
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('desktop_source', type=Path)
parser.add_argument('--port', type=int, default=18887)
parser.add_argument('--target', help='Simulate a desktop client that points to another host')
parser.add_argument('--bind', default='127.0.0.1')
args = parser.parse_args()
# Never read or clear the user's real transfer history.
root = tempfile.TemporaryDirectory(prefix='iphone-protocol-')
os.environ['TRANSFER_DATA_DIR'] = root.name
sys.path.insert(0, str(args.desktop_source.resolve()))
import server
import uvicorn
from network import Network
server.network = Network(args.port, Path(root.name), '127.0.0.1')
server.network.role = 'client' if args.target else 'host'
server.network.target = args.target or ''
server.state['messages'] = [{'id':'c'*16,'content':'电脑发来的测试文字','sender':'电脑','created_at':1791986400000}]
(server.FILE_ROOT/'desktop.txt').write_text('电脑 → iPhone 文件内容')
server.state['files'] = [{'id':'d'*16,'name':'电脑文件.txt','stored_name':'desktop.txt','size':len('电脑 → iPhone 文件内容'.encode()),'type':'text/plain','sender':'电脑','created_at':1791986401000,'download_url':'/api/files/'+'d'*16}]
uvicorn.run(server.app, host=args.bind, port=args.port)
