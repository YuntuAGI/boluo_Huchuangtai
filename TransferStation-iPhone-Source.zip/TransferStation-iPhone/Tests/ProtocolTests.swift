import Foundation

@main
struct ProtocolTests {
    static func main() async throws {
        for address in ["192.168.1.20", "http://10.0.0.1:8788/", "172.16.0.2:1", "127.0.0.1:18887", "169.254.1.2"] {
            _ = try LANEndpoint.parse(address)
        }
        for address in ["https://10.0.0.1", "8.8.8.8", "localhost", "192.168.1.1@evil.com", "http://user:pw@10.0.0.1", "10.0.0.1:0", "10.0.0.1:65536", "10.0.0.1/x", "10.0.0.1?q=x", "10.0.0.1#x", "010.0.0.1", "172.32.0.1", "192.168.1.999", "127.1"] {
            do { _ = try LANEndpoint.parse(address); fatalError("Accepted unsafe address: \(address)") } catch {}
        }
        print("PASS endpoint validation")
        guard CommandLine.arguments.count > 1 else { return }
        if CommandLine.arguments[1] == "--reject" {
            do { _ = try await TransferClient.resolve(CommandLine.arguments[2]); fatalError("Accepted unsafe host target") } catch {}
            print("PASS unsafe host target rejected")
            return
        }
        let (client, status) = try await TransferClient.resolve(CommandLine.arguments[1])
        defer { client.cancel() }
        precondition(status.protocol == "transfer-station/2")
        try await client.post("api/network/join", payload: ["id": String(repeating: "a", count: 32), "name": "iPhone 协议测试"])
        let text = "iPhone → 电脑 中文\nemoji 🐱 \(UUID())"
        try await client.send(text, sender: "iPhone 测试")
        let feed: Feed = try await client.get("api/feed")
        precondition(feed.messages.contains { $0.content == text })
        precondition(feed.messages.contains { $0.content == "电脑发来的测试文字" })
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let file = root.appendingPathComponent("中文文件 🐱.bin")
        let bytes = Data((0..<131_073).map { UInt8($0 % 251) })
        try bytes.write(to: file)
        let uploaded = try await client.upload(file, sender: "iPhone 测试")
        precondition(uploaded.name == file.lastPathComponent && uploaded.size == bytes.count)
        let saved = try await client.download(uploaded, directory: root.appendingPathComponent("received"))
        let received = try Data(contentsOf: saved)
        precondition(received == bytes)
        let desktopFile = feed.files.first { $0.name == "电脑文件.txt" }!
        let desktopDownload = try await client.download(desktopFile, directory: root)
        let desktopBytes = try Data(contentsOf: desktopDownload)
        precondition(String(data: desktopBytes, encoding: .utf8) == "电脑 → iPhone 文件内容")
        for invalidText in ["   ", String(repeating: "a", count: 10001)] {
            do { try await client.send(invalidText, sender: "test"); fatalError("Accepted invalid text") } catch {}
        }
        let invalidFile = SharedFile(id: "../api/status", name: "x", size: 0, type: "x", sender: "x", created_at: 0)
        do { _ = try await client.download(invalidFile, directory: root); fatalError("Accepted invalid ID") } catch {}
        print("PASS \(status.host): text both directions, binary upload/download, Unicode filename, desktop download, input limits")
    }
}
