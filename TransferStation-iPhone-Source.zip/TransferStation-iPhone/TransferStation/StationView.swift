import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct PickedPhoto: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .image) { received in
            let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let target = directory.appendingPathComponent(received.file.lastPathComponent)
            try FileManager.default.copyItem(at: received.file, to: target)
            return PickedPhoto(url: target)
        }
    }
}
struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
private struct ShareItem: Identifiable { let id = UUID(); let url: URL }

struct StationView: View {
    @ObservedObject var station: StationModel
    @State private var draft = ""
    @State private var showFiles = false
    @State private var photo: PhotosPickerItem?
    @State private var preparingPhoto = false
    @State private var share: ShareItem?
    @State private var filter = 0
    @FocusState private var writing: Bool
    private var ready: Bool { station.connected && station.activity == nil && !preparingPhoto }

    var body: some View {
        NavigationStack {
            Group {
                if station.endpoint.isEmpty { connectionForm }
                else { conversation }
            }
            .navigationTitle("互传站")
            .navigationBarTitleDisplayMode(station.endpoint.isEmpty ? .large : .inline)
            .toolbar {
                if !station.endpoint.isEmpty {
                    ToolbarItem(placement: .topBarTrailing) {
                        Menu {
                            Button("重新连接", systemImage: "arrow.clockwise") { Task { await station.connect() } }
                            Button("断开连接", systemImage: "wifi.slash", role: .destructive) { station.disconnect() }
                        } label: { Image(systemName: "ellipsis.circle").frame(minWidth: 44, minHeight: 44) }
                        .accessibilityLabel("连接选项")
                    }
                }
            }
        }
        .fileImporter(isPresented: $showFiles, allowedContentTypes: [.item]) { result in
            switch result {
            case .success(let url): Task { await station.upload(url) }
            case .failure(let error): station.error = StationModel.explain(error)
            }
        }
        .onChange(of: photo) { _, item in
            guard let item else { return }
            preparingPhoto = true
            let connectionID = station.connectionID
            Task {
                defer { preparingPhoto = false; photo = nil }
                do {
                    guard let picked = try await item.loadTransferable(type: PickedPhoto.self) else {
                        throw TransferFailure(message: "无法读取这张照片，请重试或从“文件”中选择。")
                    }
                    defer { try? FileManager.default.removeItem(at: picked.url.deletingLastPathComponent()) }
                    guard station.connectionID == connectionID else {
                        throw TransferFailure(message: "连接已变化，请重新选择要发送的照片。")
                    }
                    await station.upload(picked.url)
                } catch { station.error = StationModel.explain(error) }
            }
        }
        .onChange(of: station.shareURL) { _, url in
            if let url { share = ShareItem(url: url); station.shareURL = nil }
        }
        .sheet(item: $share) { item in ShareSheet(url: item.url).presentationDetents([.medium, .large]) }
    }

    private var connectionForm: some View {
        Form {
            Section {
                Label("把手机和电脑放进同一个会话", systemImage: "laptopcomputer.and.iphone")
                    .font(.headline).padding(.vertical, 8)
                Text("文字、照片和文件，直接在局域网内传递。")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Section("连接电脑") {
                TextField("192.168.1.20:8787", text: $station.address)
                    .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .accessibilityLabel("电脑地址").accessibilityIdentifier("computerAddress")
                    .disabled(station.connecting)
                TextField("发送者名称", text: $station.sender)
                    .accessibilityIdentifier("senderName").disabled(station.connecting)
                Button {
                    writing = false
                    Task { await station.connect() }
                } label: {
                    HStack {
                        if station.connecting { ProgressView() }
                        Text(station.connecting ? "正在连接…" : "连接电脑").fontWeight(.semibold)
                        Spacer()
                        Image(systemName: "arrow.right")
                    }.frame(minHeight: 32)
                }
                .accessibilityIdentifier("connectButton")
                .disabled(station.connecting || station.address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if station.connecting { Button("取消连接", role: .cancel) { station.disconnect() } }
            }
            if let error = station.error {
                Section { Label(error, systemImage: "exclamationmark.triangle").foregroundStyle(.orange) }
            }
            Section("第一次使用") {
                Label("手机与电脑连接同一个 Wi-Fi", systemImage: "wifi")
                Label("打开电脑上的互传站，找到内网地址", systemImage: "desktopcomputer")
                Label("输入地址，允许本地网络访问", systemImage: "checkmark.shield")
            }
            Section {
                Text("同一会话里的设备都能看到共享内容。请仅在信任的局域网使用；传输期间保持 App 在前台。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    private var conversation: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .top) {
                    Image(systemName: station.connected ? "wifi" : "wifi.slash")
                        .foregroundStyle(station.connected ? .green : .orange)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(station.connected ? "已连接 · \(station.host)" : "连接已中断")
                            .font(.subheadline.weight(.semibold)).accessibilityIdentifier("connectionStatus")
                        Text(station.endpoint).font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                    }
                    Spacer(minLength: 8)
                    if !station.connected {
                        Button("重连") { Task { await station.connect() } }.frame(minHeight: 44)
                    }
                }
                Picker("显示内容", selection: $filter) {
                    Text("全部").tag(0); Text("文字").tag(1); Text("文件").tag(2)
                }.pickerStyle(.segmented)
            }.padding(16)
            if entries.isEmpty {
                ContentUnavailableView("等待第一条内容", systemImage: "tray", description: Text("从下方发送文字、照片或文件，\n电脑发送的内容也会出现在这里。"))
            } else {
                List {
                    ForEach(entries) { entry in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(alignment: .firstTextBaseline) {
                                Text(entry.sender).font(.caption.weight(.medium)).foregroundStyle(.secondary)
                                Spacer()
                                Text(Date(timeIntervalSince1970: entry.time / 1000), style: .time)
                                    .font(.caption).foregroundStyle(.tertiary).monospacedDigit()
                            }
                            if let message = entry.message {
                                Text(message.content).textSelection(.enabled)
                                    .accessibilityIdentifier("message-" + message.id)
                                    .contextMenu {
                                        Button("复制文字", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.content }
                                    }
                            }
                            if let file = entry.file {
                                HStack(spacing: 12) {
                                    Image(systemName: file.type.hasPrefix("image/") ? "photo" : "doc")
                                        .font(.title2).foregroundStyle(.blue).accessibilityHidden(true)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(file.name).font(.body.weight(.medium)).lineLimit(3)
                                        Text(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file))
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer(minLength: 0)
                                    Button { Task { await station.download(file) } } label: {
                                        Image(systemName: "square.and.arrow.down").frame(minWidth: 44, minHeight: 44)
                                    }.buttonStyle(.borderless).disabled(!ready)
                                        .accessibilityLabel("接收 \(file.name)")
                                }
                            }
                        }.padding(.vertical, 8)
                    }
                }
                .listStyle(.plain).scrollDismissesKeyboard(.interactively)
                .refreshable { await station.refresh() }
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { composer }
    }

    private var composer: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let error = station.error {
                HStack(alignment: .top) {
                    Label(error, systemImage: "exclamationmark.triangle").font(.footnote).foregroundStyle(.orange)
                    Spacer(minLength: 0)
                    Button { station.error = nil } label: { Image(systemName: "xmark").frame(minWidth: 44, minHeight: 44) }.accessibilityLabel("关闭提示")
                }
            }
            if let activity = station.activity {
                HStack { ProgressView(); Text(activity).font(.footnote) }
            } else if preparingPhoto {
                HStack { ProgressView(); Text("正在读取照片…").font(.footnote) }
            } else if let notice = station.notice {
                Label(notice, systemImage: "checkmark.circle").font(.footnote).foregroundStyle(.green)
            }
            HStack(alignment: .bottom, spacing: 8) {
                TextField("输入要发送的文字", text: $draft, axis: .vertical)
                    .lineLimit(1...5).padding(12)
                    .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12))
                    .focused($writing).accessibilityIdentifier("messageInput")
                Button {
                    let sent = draft
                    Task { if await station.send(sent), draft == sent { draft = ""; writing = false } }
                } label: {
                    Image(systemName: "arrow.up.circle.fill").font(.system(size: 32))
                        .frame(minWidth: 44, minHeight: 44)
                }.disabled(!ready || draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityLabel("发送文字").accessibilityIdentifier("sendButton")
            }
            HStack(spacing: 20) {
                Button { writing = false; showFiles = true } label: { Label("文件", systemImage: "folder").frame(minHeight: 44) }.disabled(!ready)
                PhotosPicker(selection: $photo, matching: .images) {
                    Label("照片", systemImage: "photo").frame(minHeight: 44)
                }.disabled(!ready)
                Spacer(minLength: 0)
                Text("同一会话可见").font(.caption).foregroundStyle(.secondary)
            }
        }.padding(.horizontal, 16).padding(.top, 12)
            .background(.regularMaterial)
    }
    private struct Entry: Identifiable {
        let id: String
        let sender: String
        let time: Double
        var message: Message?
        var file: SharedFile?
    }
    private var entries: [Entry] {
        var items: [Entry] = []
        if filter != 2 {
            items += station.feed.messages.map { Entry(id: "m-" + $0.id, sender: $0.sender, time: $0.created_at, message: $0) }
        }
        if filter != 1 {
            items += station.feed.files.map { Entry(id: "f-" + $0.id, sender: $0.sender, time: $0.created_at, file: $0) }
        }
        return items.sorted { $0.time == $1.time ? $0.id > $1.id : $0.time > $1.time }
    }
}
