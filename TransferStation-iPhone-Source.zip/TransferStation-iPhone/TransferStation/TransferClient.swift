import Foundation

struct TransferFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct StationStatus: Decodable {
    let host: String
    let role: String
    let `protocol`: String
}
struct NetworkSnapshot: Decodable { let url: String }
struct Message: Decodable, Identifiable {
    let id: String
    let content: String
    let sender: String
    let created_at: Double
}
struct SharedFile: Decodable, Identifiable {
    let id: String
    let name: String
    let size: Int64
    let type: String
    let sender: String
    let created_at: Double
}
struct Feed: Decodable {
    let messages: [Message]
    let files: [SharedFile]
}

// Desktop v2 speaks plain HTTP. Only literal private IPv4 addresses are accepted.
enum LANEndpoint {
    static func parse(_ input: String) throws -> URL {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var c = URLComponents(string: text.contains("://") ? text : "http://" + text),
              c.scheme == "http", c.user == nil, c.password == nil,
              c.query == nil, c.fragment == nil, c.path.isEmpty || c.path == "/",
              let host = c.host else { throw invalid }
        let parts = host.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4, parts.allSatisfy({ !$0.isEmpty && $0.allSatisfy { $0.isASCII && $0.isNumber } }),
              parts.allSatisfy({ Int($0).map { (0...255).contains($0) } ?? false }) else { throw invalid }
        let n = parts.compactMap { Int($0) }
        guard zip(parts, n).allSatisfy({ String($0.0) == String($0.1) }),
              n[0] == 10 || n[0] == 127 || (n[0] == 192 && n[1] == 168) ||
              (n[0] == 172 && (16...31).contains(n[1])) || (n[0] == 169 && n[1] == 254),
              (1...65535).contains(c.port ?? 8787) else { throw invalid }
        c.port = c.port ?? 8787
        c.path = ""
        guard let url = c.url else { throw invalid }
        return url
    }
    static var invalid: TransferFailure { .init(message: "请输入电脑上的内网 IPv4 地址，例如 192.168.1.20:8787。") }
}

final class NoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class TransferClient: @unchecked Sendable {
    let base: URL
    private let session: URLSession
    init(base: URL) {
        self.base = base
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 60 * 30
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.connectionProxyDictionary = [:]
        session = URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }
    func cancel() { session.invalidateAndCancel() }
    deinit { session.invalidateAndCancel() }
    private func endpoint(_ path: String) -> URL { base.appendingPathComponent(path) }
    private func validate(_ response: URLResponse, data: Data? = nil) throws {
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            let detail = data.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }?["detail"] as? String
            throw TransferFailure(message: detail ?? "电脑返回错误（\(code)），请确认互传站仍在运行。")
        }
    }
    func get<T: Decodable>(_ path: String) async throws -> T {
        let (data, response) = try await session.data(from: endpoint(path))
        try validate(response, data: data)
        return try JSONDecoder().decode(T.self, from: data)
    }
    func post(_ path: String, payload: [String: String]) async throws {
        var req = URLRequest(url: endpoint(path))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let (data, response) = try await session.data(for: req)
        try validate(response, data: data)
    }
    static func resolve(_ input: String) async throws -> (TransferClient, StationStatus) {
        var url = try LANEndpoint.parse(input)
        var visited = Set<URL>()
        for _ in 0..<3 {
            guard visited.insert(url).inserted else { throw TransferFailure(message: "电脑正在切换主机，请稍后重新连接。") }
            let client = TransferClient(base: url)
            do {
                let status: StationStatus = try await client.get("api/status")
                guard status.protocol == "transfer-station/2" else { throw TransferFailure(message: "电脑版本不兼容，请使用本项目的 Mac 或 Windows 版。") }
                if status.role == "host" { return (client, status) }
                guard status.role == "client" else { throw TransferFailure(message: "电脑正在寻找主机，请等待几秒后重试。") }
                let network: NetworkSnapshot = try await client.get("api/network")
                url = try LANEndpoint.parse(network.url)
                client.cancel()
            } catch { client.cancel(); throw error }
        }
        throw TransferFailure(message: "找不到当前主机，请输入标记为主机的电脑地址。")
    }
    func send(_ text: String, sender: String) async throws {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, clean.unicodeScalars.count <= 10000 else {
            throw TransferFailure(message: "文字不能为空，且每条最多 10000 字。")
        }
        try await post("api/messages", payload: ["content": clean, "sender": sender])
    }
    func upload(_ source: URL, sender: String, mime: String = "application/octet-stream") async throws -> SharedFile {
        // Build multipart on disk, not in RAM, so large files do not exhaust the phone.
        let boundary = UUID().uuidString
        let builder = Task.detached { try Self.multipart(source, sender: sender, mime: mime, boundary: boundary) }
        let body = try await withTaskCancellationHandler { try await builder.value } onCancel: { builder.cancel() }
        defer { try? FileManager.default.removeItem(at: body) }
        try Task.checkCancellation()
        var req = URLRequest(url: endpoint("api/files"))
        req.httpMethod = "POST"
        req.timeoutInterval = 1800
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        let (data, response) = try await session.upload(for: req, fromFile: body)
        try validate(response, data: data)
        return try JSONDecoder().decode(SharedFile.self, from: data)
    }
    static func multipart(_ source: URL, sender: String, mime: String, boundary: String) throws -> URL {
        let size = try source.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
        guard size.isRegularFile == true, let count = size.fileSize, count <= 1_073_741_824 else {
            throw TransferFailure(message: "请选择不超过 1 GB 的单个文件。")
        }
        let body = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".multipart")
        guard FileManager.default.createFile(atPath: body.path, contents: nil) else { throw TransferFailure(message: "无法创建上传缓存，请检查剩余空间。") }
        do {
            let output = try FileHandle(forWritingTo: body)
            defer { try? output.close() }
            let input = try FileHandle(forReadingFrom: source)
            defer { try? input.close() }
            let name = source.lastPathComponent.replacingOccurrences(of: "\r", with: "_").replacingOccurrences(of: "\n", with: "_").replacingOccurrences(of: "\"", with: "_").replacingOccurrences(of: "\\", with: "_")
            let safeMime = mime.contains("\r") || mime.contains("\n") ? "application/octet-stream" : mime
            try output.write(contentsOf: Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"sender\"\r\n\r\n\(sender)\r\n--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"\(name)\"\r\nContent-Type: \(safeMime)\r\n\r\n".utf8))
            var total = 0
            while let chunk = try input.read(upToCount: 1_048_576), !chunk.isEmpty {
                try Task.checkCancellation()
                total += chunk.count
                guard total <= 1_073_741_824 else { throw TransferFailure(message: "文件超过 1 GB。") }
                try output.write(contentsOf: chunk)
            }
            try output.write(contentsOf: Data("\r\n--\(boundary)--\r\n".utf8))
            return body
        } catch { try? FileManager.default.removeItem(at: body); throw error }
    }
    func download(_ file: SharedFile, directory: URL) async throws -> URL {
        guard file.id.count == 16, file.id.allSatisfy({ "0123456789abcdef".contains($0) }) else {
            throw TransferFailure(message: "文件标识无效。")
        }
        let (temp, response) = try await session.download(from: endpoint("api/files/" + file.id))
        defer { try? FileManager.default.removeItem(at: temp) }
        try validate(response)
        let size = try temp.resourceValues(forKeys: [.fileSizeKey]).fileSize
        guard size.map({ Int64($0) }) == file.size else { throw TransferFailure(message: "下载不完整，请重试。") }
        let folder = directory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let rawName = (file.name as NSString).lastPathComponent
        let name = rawName.isEmpty || rawName == "." || rawName == ".." ? "收到的文件" : rawName
        let target = folder.appendingPathComponent(name)
        try FileManager.default.moveItem(at: temp, to: target)
        return target
    }
}
