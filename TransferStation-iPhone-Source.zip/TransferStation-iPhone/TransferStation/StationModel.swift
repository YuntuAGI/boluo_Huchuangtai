import SwiftUI
import UniformTypeIdentifiers

@MainActor
final class StationModel: ObservableObject {
    @Published var address = UserDefaults.standard.string(forKey: "stationAddress") ?? ""
    @Published var sender = UserDefaults.standard.string(forKey: "senderName") ?? "iPhone"
    @Published var host = ""
    @Published var endpoint = ""
    @Published var feed = Feed(messages: [], files: [])
    @Published var connected = false
    @Published var connecting = false
    @Published var activity: String?
    @Published var error: String?
    @Published var notice: String?
    @Published var shareURL: URL?
    @Published var lastUpdated: Date?
    private var client: TransferClient?
    private var poll: Task<Void, Never>?
    private var generation = UUID()
    var connectionID: UUID { generation }
    private var active = true
    private var interrupted = false
    private var deviceID: String {
        if let value = UserDefaults.standard.string(forKey: "deviceID") { return value }
        let value = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
        UserDefaults.standard.set(value, forKey: "deviceID")
        return value
    }
    var displaySender: String {
        let text = sender.trimmingCharacters(in: .whitespacesAndNewlines)
        return text.isEmpty ? "iPhone" : String(text.prefix(40))
    }
    func disconnect() {
        generation = UUID()
        poll?.cancel(); poll = nil
        client?.cancel(); client = nil
        connected = false; connecting = false; activity = nil
        host = ""; endpoint = ""; feed = Feed(messages: [], files: [])
        lastUpdated = nil; notice = nil; error = nil
    }
    func connect() async {
        disconnect()
        let token = generation
        connecting = true
        do {
            let (candidate, status) = try await TransferClient.resolve(address)
            guard generation == token, active else { candidate.cancel(); return }
            client = candidate
            let initial: Feed = try await candidate.get("api/feed")
            guard generation == token, active else { return }
            feed = initial; host = status.host; endpoint = candidate.base.absoluteString
            connected = true; connecting = false; lastUpdated = Date()
            if interrupted {
                error = "上次传输因离开 App 中断。请先检查会话记录，再决定是否重试。"
                interrupted = false
            }
            UserDefaults.standard.set(address, forKey: "stationAddress")
            UserDefaults.standard.set(displaySender, forKey: "senderName")
            poll = Task { [weak self] in
                while !Task.isCancelled {
                    guard let self, self.generation == token else { return }
                    await self.refresh()
                    do { try await Task.sleep(for: .seconds(2)) } catch { return }
                }
            }
        } catch {
            guard generation == token else { return }
            client?.cancel(); client = nil; connecting = false
            self.error = Self.explain(error)
        }
    }
    func refresh() async {
        guard let client, active else { return }
        let token = generation
        do {
            let latest: Feed = try await client.get("api/feed")
            try await client.post("api/network/join", payload: ["id": deviceID, "name": displaySender])
            guard generation == token, active else { return }
            if !connected { error = nil }
            feed = latest; connected = true; lastUpdated = Date()
        } catch {
            guard generation == token, active, !Task.isCancelled else { return }
            connected = false
            self.error = "连接中断，正在重试。若电脑切换了主机，请重新连接。\n" + Self.explain(error)
        }
    }
    func setActive(_ value: Bool) {
        active = value
        if !value {
            // iOS may suspend foreground transfers; never claim persistent background delivery.
            generation = UUID(); poll?.cancel(); poll = nil
            client?.cancel(); client = nil; connected = false; connecting = false
            if activity != nil { interrupted = true; error = "传输已中断。回到前台后，请先检查记录再重试，避免重复发送。" }
            activity = nil
        } else if !endpoint.isEmpty {
            Task { await connect() }
        }
    }
    func send(_ text: String) async -> Bool {
        guard let client, connected, activity == nil else { return false }
        let token = generation
        activity = "正在发送文字…"; error = nil; notice = nil
        do {
            try await client.send(text, sender: displaySender)
            guard generation == token else { return false }
            activity = nil; notice = "文字已发送"; await refresh()
            return true
        } catch {
            guard generation == token else { return false }
            activity = nil; self.error = Self.explain(error) + " 若连接中断，请先查看记录，避免重复发送。"
            return false
        }
    }
    func upload(_ url: URL, mime: String? = nil) async {
        guard let client, connected, activity == nil else { return }
        let token = generation
        activity = "正在发送 \(url.lastPathComponent)…"; error = nil; notice = nil
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let type = mime ?? UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            _ = try await client.upload(url, sender: displaySender, mime: type)
            guard generation == token else { return }
            activity = nil; notice = "文件已发送"; await refresh()
        } catch {
            guard generation == token else { return }
            activity = nil; self.error = Self.explain(error) + " 若连接中断，请先查看记录，避免重复上传。"
        }
    }
    func download(_ file: SharedFile) async {
        guard let client, connected, activity == nil else { return }
        let token = generation
        activity = "正在接收 \(file.name)…"; error = nil; notice = nil
        do {
            let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let url = try await client.download(file, directory: documents.appendingPathComponent("收到的文件"))
            guard generation == token else { return }
            activity = nil; notice = "已保存到本机，可在“文件”中查看"; shareURL = url
        } catch {
            guard generation == token else { return }
            activity = nil; self.error = Self.explain(error)
        }
    }
    static func explain(_ error: Error) -> String {
        if let failure = error as? TransferFailure { return failure.message }
        if error is DecodingError { return "电脑返回的数据不兼容，请确认使用本项目的互传站。" }
        if let urlError = error as? URLError {
            if urlError.code == .cancelled { return "操作已取消。" }
            return "无法连接电脑。请确认同一 Wi-Fi、电脑互传站已打开，并在系统设置中允许“互传站”的本地网络访问。"
        }
        return error.localizedDescription
    }
}
