import SwiftUI

@main
struct TransferStationApp: App {
    @StateObject private var station = StationModel()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            StationView(station: station)
                .tint(.blue)
                .onChange(of: phase) { _, value in
                    if value == .background { station.setActive(false) }
                    if value == .active { station.setActive(true) }
                }
        }
    }
}
